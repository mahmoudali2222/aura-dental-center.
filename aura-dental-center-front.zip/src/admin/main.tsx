import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import '../shared/styles/tokens.css';
import '../shared/styles/base.css';
import './admin.css';
import { AdminProviders } from './app/Providers.js';
import { AdminRoutes } from './App.js';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter basename="/admin">
      <AdminProviders>
        <AdminRoutes />
      </AdminProviders>
    </BrowserRouter>
  </StrictMode>,
);
