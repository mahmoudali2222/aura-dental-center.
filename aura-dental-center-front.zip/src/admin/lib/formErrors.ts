import type { I18n } from '../../shared/i18n/I18nProvider.js';
import { fieldErrors } from '../../shared/lib/errors.js';
import { toApiError } from '../../shared/lib/useAsync.js';

/**
 * Field-level messages for a failed write. Besides the backend's per-field validation issues (keyed by the backend's own
 * path, e.g. "phone" or "translations.ar.name"), a few single-purpose codes belong to one field (a taken phone number is the
 * phone field's problem): `byCode` maps them. Whatever is not attached to a field comes back as `rest`, to be shown once
 * in an alert.
 */
export function formErrors(i18n: I18n, err: unknown, byCode: Record<string, string> = {}): { fields: Record<string, string>; rest: unknown } {
  if (!err) return { fields: {}, rest: null };
  const fields = fieldErrors(i18n, err);
  const code = toApiError(err).code;
  const field = byCode[code];
  if (field) {
    fields[field] = i18n.t(`err.${code}`);
    return { fields, rest: null };
  }
  return { fields, rest: Object.keys(fields).length > 0 && code === 'VALIDATION_ERROR' ? null : err };
}
