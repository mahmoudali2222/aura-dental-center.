import { useCallback, useRef, useState } from 'react';

/**
 * Wraps a write (save, cancel, create...) with busy and error state. A second call while one is running is ignored,
 * so a double click cannot submit twice.
 *  - `run(...)` resolves to the result, or to undefined when the call failed (the error is then in `error`).
 *  - `attempt(...)` resolves to true when the call succeeded and false when it failed: use it for calls without a body
 *    (204), where "undefined" would be ambiguous.
 */
export function useAction<A extends unknown[], R>(fn: (...args: A) => Promise<R>) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const fnRef = useRef(fn);
  fnRef.current = fn;
  const running = useRef(false);

  const exec = useCallback(async (args: A): Promise<{ ok: true; value: R } | { ok: false }> => {
    if (running.current) return { ok: false };
    running.current = true;
    setBusy(true);
    setError(null);
    try {
      return { ok: true, value: await fnRef.current(...args) };
    } catch (e) {
      setError(e);
      return { ok: false };
    } finally {
      running.current = false;
      setBusy(false);
    }
  }, []);

  const run = useCallback(async (...args: A): Promise<R | undefined> => {
    const r = await exec(args);
    return r.ok ? r.value : undefined;
  }, [exec]);
  const attempt = useCallback(async (...args: A): Promise<boolean> => (await exec(args)).ok, [exec]);

  const reset = useCallback(() => setError(null), []);
  return { run, attempt, busy, error, reset };
}
