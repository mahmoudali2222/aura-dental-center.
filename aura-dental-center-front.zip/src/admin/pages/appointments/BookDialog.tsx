import { useEffect, useRef, useState, type FormEvent } from 'react';
import { Alert, Button, Dialog, SelectField, TextAreaField, TextField } from '../../../shared/ui/index.js';
import { errorText, fieldErrors } from '../../../shared/lib/errors.js';
import { toApiError, useAsync } from '../../../shared/lib/useAsync.js';
import { useI18n } from '../../../shared/i18n/I18nProvider.js';
import { admin } from '../../api/index.js';
import type { AdminAppointment, AdminPatient } from '../../api/types.js';
import { useT } from '../../i18n/useT.js';
import { SlotChooser, type SlotChoice } from './SlotChooser.js';

const STALE = new Set(['SLOT_UNAVAILABLE', 'DAILY_CAPACITY_REACHED', 'SLOT_IN_PAST', 'DATE_CLOSED', 'BEYOND_BOOKING_HORIZON']);

export function BookDialog({ open, onClose, onBooked }: { open: boolean; onClose: () => void; onBooked: () => void }) {
  const t = useT();
  return (
    <Dialog open={open} title={t('appts.book.title')} onClose={onClose}>
      {open ? <Form onClose={onClose} onBooked={onBooked} /> : null}
    </Dialog>
  );
}

function Form({ onClose, onBooked }: { onClose: () => void; onBooked: () => void }) {
  const t = useT();
  const i18n = useI18n();
  const [search, setSearch] = useState('');
  const [found, setFound] = useState<AdminPatient[] | null>(null);
  const [patient, setPatient] = useState<AdminPatient | null>(null);
  const [departmentId, setDepartmentId] = useState('');
  const [serviceId, setServiceId] = useState('');
  const [choice, setChoice] = useState<SlotChoice | null>(null);
  const [note, setNote] = useState('');
  const [refreshKey, setRefreshKey] = useState(0);
  const [stale, setStale] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [booked, setBooked] = useState<AdminAppointment | null>(null);
  const running = useRef(false);

  const depts = useAsync((signal) => admin.departments.list(signal), []);
  const bookable = (depts.data ?? []).filter((d) => d.bookable);
  const department = bookable.find((d) => d.id === departmentId) ?? null;
  const services = useAsync((signal) => (departmentId ? admin.services.list(departmentId, signal) : Promise.resolve([])), [departmentId]);

  // patient search: only after a short pause, and only for 2+ characters
  useEffect(() => {
    const q = search.trim();
    if (patient || q.length < 2) { setFound(null); return; }
    const controller = new AbortController();
    const timer = setTimeout(() => {
      admin.patients.list({ q }, 1, 8, controller.signal).then((r) => { if (!controller.signal.aborted) setFound(r.data); }, () => { if (!controller.signal.aborted) setFound([]); });
    }, 250);
    return () => { clearTimeout(timer); controller.abort(); };
  }, [search, patient]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (running.current || !patient || !department || !choice) return;
    running.current = true; setBusy(true); setError(null);
    try {
      const a = await admin.appointments.create({ patientId: patient.id, departmentId: department.id, serviceId: serviceId || null, date: choice.date, slotNumber: choice.slotNumber, ...(note.trim() ? { patientNote: note.trim() } : {}) }, i18n.locale);
      setBooked(a); onBooked();
    } catch (err) {
      setError(err);
      if (STALE.has(toApiError(err).code)) { setChoice(null); setRefreshKey((k) => k + 1); setStale(true); }
    } finally { running.current = false; setBusy(false); }
  }

  if (booked) {
    return (
      <div className="stack">
        <Alert tone="success" title={t('appts.book.done')}>
          {t('appts.book.summary', { patient: booked.patient.fullName, department: booked.department.name, date: i18n.date(booked.date), time: i18n.range(booked.startTime, booked.endTime) })}
        </Alert>
        <div className="row">
          <Button variant="secondary" onClick={() => { setBooked(null); setChoice(null); setNote(''); setStale(false); setRefreshKey((k) => k + 1); }}>{t('appts.book.another')}</Button>
          <Button variant="ghost" onClick={onClose}>{t('common.close')}</Button>
        </div>
      </div>
    );
  }

  const f = fieldErrors(i18n, error);
  return (
    <form onSubmit={submit} className="stack" noValidate>
      {!patient ? (
        <div className="stack">
          <TextField label={t('appts.book.patient.search')} hint={t('appts.book.patient.hint')} value={search} onChange={(e) => setSearch(e.target.value)} autoComplete="off" />
          {found && found.length === 0 ? <p className="muted">{t('appts.book.patient.none')}</p> : null}
          {found && found.length > 0 ? (
            <ul className="stack" style={{ listStyle: 'none', padding: 0, margin: 0 }} aria-label={t('appts.book.patient.choose')}>
              {found.map((p) => (
                <li key={p.id}><Button variant="ghost" onClick={() => { setPatient(p); setFound(null); }}>{p.fullName} · <span className="ltr">{p.phone}</span></Button></li>
              ))}
            </ul>
          ) : null}
        </div>
      ) : (
        <p className="row"><strong>{patient.fullName}</strong> <span className="ltr muted">{patient.phone}</span>
          <Button small variant="ghost" onClick={() => { setPatient(null); setSearch(''); }}>{t('common.edit')}</Button></p>
      )}

      {depts.status === 'success' && bookable.length === 0 ? <Alert tone="warning">{t('appts.book.noDepartments')}</Alert> : null}
      <SelectField label={t('appts.book.department')} value={departmentId} onChange={(e) => { setDepartmentId(e.target.value); setServiceId(''); setChoice(null); setStale(false); }} error={f.departmentId}>
        <option value="">{t('appts.book.department.choose')}</option>
        {bookable.map((d) => <option key={d.id} value={d.id}>{d.translations[i18n.locale]?.name || Object.values(d.translations).find((x) => x?.name)?.name || d.slug}</option>)}
      </SelectField>
      {department && (services.data ?? []).some((s) => s.isActive) ? (
        <SelectField label={t('appts.book.service')} optional value={serviceId} onChange={(e) => setServiceId(e.target.value)} error={f.serviceId}>
          <option value="">{t('appts.book.service.none')}</option>
          {(services.data ?? []).filter((s) => s.isActive).map((s) => <option key={s.id} value={s.id}>{s.translations[i18n.locale]?.name || Object.values(s.translations).find((x) => x?.name)?.name || ''}</option>)}
        </SelectField>
      ) : null}
      {department ? <SlotChooser slug={department.slug} value={choice} onChange={setChoice} refreshKey={refreshKey} notice={stale} /> : null}
      <TextAreaField label={t('appts.book.note')} optional hint={t('appts.book.note.hint')} maxLength={500} value={note} onChange={(e) => setNote(e.target.value)} error={f.patientNote} />
      {error ? <Alert tone="error">{errorText(i18n, error, { PATIENT_OVERLAP: 'appts.err.PATIENT_OVERLAP' })}</Alert> : null}
      <div className="row">
        <Button type="submit" loading={busy} disabled={!patient || !department || !choice}>{t('appts.book.submit')}</Button>
        <Button variant="ghost" onClick={onClose}>{t('common.cancel')}</Button>
      </div>
    </form>
  );
}
