import { useState, type FormEvent } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { Alert, Button, LanguageSwitcher, Loading, TextField } from '../../shared/ui/index.js';
import { errorText, fieldErrors } from '../../shared/lib/errors.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { useSession } from '../app/session.js';
import { useT } from '../i18n/useT.js';

export function Login() {
  const t = useT();
  const i18n = useI18n();
  const { status, login, expired } = useSession();
  const state = (useLocation().state ?? {}) as { from?: string };
  const target = state.from && state.from.startsWith('/') && !state.from.startsWith('//') ? state.from : '/';
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);

  if (status === 'loading') return <div className="public-frame"><Loading /></div>;
  if (status === 'authenticated') return <Navigate to={target} replace />;

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true); setError(null);
    try { await login({ username: username.trim(), password }); }
    catch (err) { setError(err); }
    finally { setBusy(false); }
  }
  const fields = fieldErrors(i18n, error);
  return (
    <div className="public-frame stack">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <strong>{t('admin.title')}</strong>
        <LanguageSwitcher />
      </div>
      <form onSubmit={submit} className="stack" noValidate>
        <h1>{t('login.title')}</h1>
        {expired ? <Alert tone="warning">{t('login.expired')}</Alert> : null}
        {error ? <Alert tone="error">{errorText(i18n, error)}</Alert> : null}
        <TextField label={t('login.username')} name="username" autoComplete="username" autoCapitalize="none" spellCheck={false} dir="ltr" required value={username} onChange={(e) => setUsername(e.target.value)} error={fields.username} />
        <TextField label={t('login.password')} name="password" type="password" autoComplete="current-password" dir="ltr" required value={password} onChange={(e) => setPassword(e.target.value)} error={fields.password} />
        <Button type="submit" loading={busy} disabled={!username || !password}>{t('login.submit')}</Button>
        <p className="muted">{t('login.patientsNote')}</p>
      </form>
    </div>
  );
}
