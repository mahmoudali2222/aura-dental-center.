import { useState } from 'react';
import { Alert, Button, EmptyState, Loading, SelectField } from '../../shared/ui/index.js';
import { useAsync } from '../../shared/lib/useAsync.js';
import { errorText } from '../../shared/lib/errors.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { admin } from '../api/index.js';
import type { AdminService } from '../api/types.js';
import { ConfirmDialog } from '../components/ConfirmDialog.js';
import { useAction } from '../lib/useAction.js';
import { useT } from '../i18n/useT.js';
import { ServiceDialog } from './catalog/ServiceForm.js';
import { pickName } from './catalog/shared.js';

export function Services() {
  const t = useT();
  const i18n = useI18n();
  const [departmentId, setDepartmentId] = useState('');
  const depts = useAsync((signal) => admin.departments.list(signal), []);
  const center = useAsync((signal) => admin.settings.center(signal), []);
  const list = useAsync((signal) => admin.services.list(departmentId || undefined, signal), [departmentId]);
  const [notice, setNotice] = useState<string | null>(null);
  const [editing, setEditing] = useState<AdminService | 'new' | null>(null);
  const [deactivating, setDeactivating] = useState<AdminService | null>(null);
  const toggle = useAction((id: string, isActive: boolean) => admin.services.update(id, { isActive }));
  const currency = center.data?.currency ?? 'EGP';
  const departments = depts.data ?? [];
  const deptName = (id: string) => { const d = departments.find((x) => x.id === id); return d ? pickName(d.translations, i18n.locale, d.slug) : ''; };
  const name = (s: AdminService) => pickName(s.translations, i18n.locale);
  const saved = (m: string) => { setNotice(m); list.reload(); };
  const rows = list.data ?? [];

  return (
    <div className="stack">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h1 style={{ margin: 0 }}>{t('svc.title')}</h1>
        <Button onClick={() => { setNotice(null); setEditing('new'); }}>{t('svc.add')}</Button>
      </div>
      <p className="muted">{t('svc.intro')}</p>
      <div className="toolbar">
        <SelectField label={t('svc.filter.department')} value={departmentId} onChange={(e) => setDepartmentId(e.target.value)}>
          <option value="">{t('svc.filter.all')}</option>
          {departments.map((d) => <option key={d.id} value={d.id}>{pickName(d.translations, i18n.locale, d.slug)}</option>)}
        </SelectField>
      </div>
      {rows.some((s) => s.isSample) ? <Alert tone="info">{t('svc.sampleNote')}</Alert> : null}
      {notice ? <Alert tone="success">{notice}</Alert> : null}
      {toggle.error && !deactivating ? <Alert tone="error">{errorText(i18n, toggle.error)}</Alert> : null}
      {list.status === 'loading' && !list.data ? <Loading /> : null}
      {list.status === 'error' ? <Alert tone="error">{t('admin.loadFailed')} {errorText(i18n, list.error)} <Button small variant="secondary" onClick={list.reload}>{t('common.retry')}</Button></Alert> : null}
      {list.data && rows.length === 0 ? <EmptyState>{t('svc.empty')}</EmptyState> : null}
      {rows.length > 0 ? (
        <div className="table-wrap">
          <table>
            <thead><tr>
              <th scope="col">{t('svc.col.name')}</th><th scope="col">{t('admin.col.department')}</th><th scope="col">{t('svc.col.price')}</th>
              <th scope="col">{t('svc.col.order')}</th><th scope="col">{t('admin.col.status')}</th><th scope="col">{t('admin.col.actions')}</th>
            </tr></thead>
            <tbody>
              {rows.map((s) => (
                <tr key={s.id}>
                  <td>{name(s)} {s.isSample ? <span className="badge badge--no_show">{t('common.sample')}</span> : null}</td>
                  <td>{deptName(s.departmentId)}</td>
                  <td>{s.price == null ? <span className="muted">{t('svc.price.notShown')}</span> : i18n.price(s.price, currency)}</td>
                  <td>{s.displayOrder}</td>
                  <td><span className={s.isActive ? 'badge badge--completed' : 'badge badge--cancelled'}>{s.isActive ? t('svc.badge.active') : t('svc.badge.inactive')}</span></td>
                  <td>
                    <div className="row">
                      <Button small variant="secondary" aria-label={t('svc.editAria', { name: name(s) })} onClick={() => { setNotice(null); setEditing(s); }}>{t('common.edit')}</Button>
                      {s.isActive
                        ? <Button small variant="ghost" aria-label={t('svc.deactivateAria', { name: name(s) })} onClick={() => { setNotice(null); toggle.reset(); setDeactivating(s); }}>{t('svc.deactivate')}</Button>
                        : <Button small variant="ghost" aria-label={t('svc.activateAria', { name: name(s) })} onClick={async () => { setNotice(null); if (await toggle.attempt(s.id, true)) saved(t('svc.saved.activated', { name: name(s) })); }}>{t('svc.activate')}</Button>}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}

      <ServiceDialog open={editing !== null} service={editing === 'new' ? null : editing} departments={departments} defaultDepartmentId={departmentId} currency={currency} onClose={() => setEditing(null)} onSaved={saved} />
      {deactivating ? (
        <ConfirmDialog open danger title={t('svc.deactivate.title', { name: name(deactivating) })} confirmLabel={t('svc.deactivate.confirm')} busy={toggle.busy} error={toggle.error}
          onClose={() => { toggle.reset(); setDeactivating(null); }}
          onConfirm={async () => { if (await toggle.attempt(deactivating.id, false)) { saved(t('svc.saved.deactivated', { name: name(deactivating) })); setDeactivating(null); } }}>
          <p>{t('svc.deactivate.text')}</p>
        </ConfirmDialog>
      ) : null}
    </div>
  );
}
