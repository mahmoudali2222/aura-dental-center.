import { useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { Alert, Button, EmptyState, Loading, SelectField, TextField } from '../../shared/ui/index.js';
import { useAsync } from '../../shared/lib/useAsync.js';
import { errorText } from '../../shared/lib/errors.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { admin } from '../api/index.js';
import { Pagination } from '../components/Pagination.js';
import { useT } from '../i18n/useT.js';
import { CreatePatientDialog } from './patients/CreatePatientDialog.js';
import { CENTER_ZONE, languageName } from './patients/shared.js';

const PAGE_SIZE = 25;

export function Patients() {
  const t = useT();
  const i18n = useI18n();
  const [q, setQ] = useState('');
  const [active, setActive] = useState<'' | 'true' | 'false'>('');
  const [applied, setApplied] = useState<{ q: string; active: '' | 'true' | 'false' }>({ q: '', active: '' });
  const [page, setPage] = useState(1);
  const [creating, setCreating] = useState(false);
  const list = useAsync((signal) => admin.patients.list({ ...(applied.q ? { q: applied.q } : {}), ...(applied.active ? { active: applied.active } : {}) }, page, PAGE_SIZE, signal), [applied, page]);

  function search(e: FormEvent) { e.preventDefault(); setPage(1); setApplied({ q: q.trim(), active }); }

  return (
    <div className="stack">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h1 style={{ margin: 0 }}>{t('pat.title')}</h1>
        <Button onClick={() => setCreating(true)}>{t('pat.add')}</Button>
      </div>
      <form onSubmit={search} className="toolbar" role="search" aria-label={t('pat.title')}>
        <TextField label={t('pat.search.label')} type="search" value={q} onChange={(e) => setQ(e.target.value)} maxLength={80} />
        <SelectField label={t('pat.filter.label')} value={active} onChange={(e) => setActive(e.target.value as '' | 'true' | 'false')}>
          <option value="">{t('pat.filter.all')}</option>
          <option value="true">{t('pat.filter.active')}</option>
          <option value="false">{t('pat.filter.inactive')}</option>
        </SelectField>
        <Button type="submit">{t('common.search')}</Button>
        <Button variant="ghost" onClick={() => { setQ(''); setActive(''); setPage(1); setApplied({ q: '', active: '' }); }}>{t('common.clear')}</Button>
      </form>

      {list.status === 'loading' && !list.data ? <Loading /> : null}
      {list.status === 'error' ? <Alert tone="error">{t('admin.loadFailed')} {errorText(i18n, list.error)} <Button small variant="secondary" onClick={list.reload}>{t('common.retry')}</Button></Alert> : null}
      {list.data ? <p aria-live="polite" className="muted">{i18n.tn('admin.results', list.data.meta.total)}</p> : null}
      {list.data && list.data.data.length === 0 ? <EmptyState>{t('pat.empty')}</EmptyState> : null}
      {list.data && list.data.data.length > 0 ? (
        <div className="table-wrap">
          <table>
            <thead><tr>
              <th scope="col">{t('pat.col.name')}</th><th scope="col">{t('admin.col.phone')}</th><th scope="col">{t('pat.col.language')}</th>
              <th scope="col">{t('admin.col.status')}</th><th scope="col">{t('pat.col.created')}</th><th scope="col">{t('pat.col.lastLogin')}</th>
            </tr></thead>
            <tbody>
              {list.data.data.map((p) => (
                <tr key={p.id}>
                  <td><Link to={`/patients/${p.id}`}>{p.fullName}</Link></td>
                  <td><span className="ltr">{p.phone}</span></td>
                  <td>{languageName(p.preferredLocale, t('common.none'))}</td>
                  <td><span className={p.isActive ? 'badge badge--completed' : 'badge badge--cancelled'}>{p.isActive ? t('pat.active') : t('pat.inactive')}</span></td>
                  <td>{i18n.instant(p.createdAt, CENTER_ZONE)}</td>
                  <td>{p.lastLoginAt ? i18n.instant(p.lastLoginAt, CENTER_ZONE) : <span className="muted">{t('pat.never')}</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}
      <Pagination meta={list.data?.meta} onPage={setPage} />
      <CreatePatientDialog open={creating} onClose={() => setCreating(false)} />
    </div>
  );
}
