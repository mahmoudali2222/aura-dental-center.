import { LOCALE_META } from '../../../shared/i18n/types.js';
import type { Locale } from '../../../shared/api/types.js';
export { CENTER_ZONE } from '../../lib/dates.js';

export const languageName = (l: Locale | null | undefined, none: string) => (l ? LOCALE_META[l].nativeName : none);
export { formErrors } from '../../lib/formErrors.js';
