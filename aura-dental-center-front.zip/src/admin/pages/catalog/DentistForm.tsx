import { useRef, useState, type FormEvent } from 'react';
import { Alert, Button, Dialog, TextField } from '../../../shared/ui/index.js';
import { errorText } from '../../../shared/lib/errors.js';
import { useI18n } from '../../../shared/i18n/I18nProvider.js';
import { admin } from '../../api/index.js';
import type { AdminDepartment } from '../../api/types.js';
import { TranslationFields } from '../../components/TranslationFields.js';
import { formErrors } from '../../lib/formErrors.js';
import { trToForm, trToPayload } from '../../lib/translations.js';
import { useT } from '../../i18n/useT.js';
import { pickName } from './shared.js';

const KEYS = ['name', 'bio'] as const;
export type DentistMode = 'assign' | 'replace' | 'edit';

/** Assign (department has none), replace (the confirmed replacement of the current one) or edit the department's dentist. */
export function DentistDialog({ mode, department, onClose, onSaved }: { mode: DentistMode | null; department: AdminDepartment | null; onClose: () => void; onSaved: (message: string) => void }) {
  const t = useT();
  const i18n = useI18n();
  const name = department ? pickName(department.translations, i18n.locale, department.slug) : '';
  const title = mode === 'edit' ? t('dep.dentist.form.editTitle', { department: name }) : mode === 'replace' ? t('dep.dentist.form.replaceTitle', { department: name }) : t('dep.dentist.form.assignTitle', { department: name });
  return (
    <Dialog open={!!mode && !!department} title={title} onClose={onClose}>
      {mode && department ? <Form key={`${department.id}-${mode}`} mode={mode} department={department} departmentName={name} onClose={onClose} onSaved={onSaved} /> : null}
    </Dialog>
  );
}

function Form({ mode, department, departmentName, onClose, onSaved }: { mode: DentistMode; department: AdminDepartment; departmentName: string; onClose: () => void; onSaved: (message: string) => void }) {
  const t = useT();
  const i18n = useI18n();
  const current = mode === 'edit' ? department.dentist : null;
  const [photoPath, setPhotoPath] = useState(current?.photoPath ?? '');
  const [tr, setTr] = useState(() => trToForm(current?.translations, KEYS));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const running = useRef(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (running.current) return;
    running.current = true; setBusy(true); setError(null);
    const translations = trToPayload(tr, KEYS, current?.translations);
    try {
      if (mode === 'edit' && current) await admin.dentists.update(current.id, { photoPath: photoPath.trim() || null, translations });
      else await admin.dentists.create({ departmentId: department.id, ...(mode === 'replace' ? { replaceExisting: true } : {}), photoPath: photoPath.trim() || null, translations });
      onSaved(t(mode === 'edit' ? 'dep.dentist.saved.updated' : mode === 'replace' ? 'dep.dentist.saved.replaced' : 'dep.dentist.saved.assigned', { department: departmentName }));
      onClose();
    } catch (err) { setError(err); }
    finally { running.current = false; setBusy(false); }
  }
  const { fields, rest } = formErrors(i18n, error, { INVALID_IMAGE_PATH: 'photoPath' });
  const named = (['ar', 'en', 'fr'] as const).some((l) => (tr[l].name ?? '').trim() !== '');
  return (
    <form onSubmit={submit} className="stack" noValidate>
      <p className="muted">{t('dep.dentist.noLogin')}</p>
      {rest ? <Alert tone="error">{errorText(i18n, rest)}</Alert> : null}
      <TextField label={t('dep.dentist.photo')} optional hint={t('admin.image.hint')} dir="ltr" value={photoPath} onChange={(e) => setPhotoPath(e.target.value)} error={fields.photoPath} />
      <TranslationFields legend={t('dep.dentist.tr.legend')} value={tr} onChange={setTr} errors={fields}
        fields={[{ key: 'name', label: t('dep.dentist.tr.name'), maxLength: 120 }, { key: 'bio', label: t('dep.dentist.tr.bio'), multiline: true, maxLength: 2000 }]} />
      <div className="row">
        <Button type="submit" loading={busy} disabled={!named}>{t('common.save')}</Button>
        <Button variant="ghost" onClick={onClose}>{t('common.cancel')}</Button>
      </div>
    </form>
  );
}
