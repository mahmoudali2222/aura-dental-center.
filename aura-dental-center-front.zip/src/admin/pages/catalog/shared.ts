import type { Locale } from '../../../shared/api/types.js';
import { LOCALES } from '../../../shared/api/types.js';
import type { Translations } from '../../api/types.js';

/** The text to show for something that has per-language names: the current language, else any language that has one. */
export function pickName(tr: Translations<{ name?: string }> | undefined, locale: Locale, fallback = ''): string {
  const own = tr?.[locale]?.name?.trim();
  if (own) return own;
  for (const l of LOCALES) { const n = tr?.[l]?.name?.trim(); if (n) return n; }
  return fallback;
}

export const ORDER_RE = /^\d{1,5}$/;
export const validOrder = (s: string) => ORDER_RE.test(s.trim()) && Number(s) >= 0 && Number(s) <= 10000;

/** A text field of a per-language record, in the current language, else in any language that has it. */
export function pickText<K extends string>(tr: Partial<Record<Locale, Partial<Record<K, string>>>> | undefined, locale: Locale, key: K): string {
  const own = tr?.[locale]?.[key]?.trim();
  if (own) return own;
  for (const l of LOCALES) { const v = tr?.[l]?.[key]?.trim(); if (v) return v; }
  return '';
}
