import { useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { Alert, Button, EmptyState, Loading, SelectField, StatusBadge, TextField } from '../../shared/ui/index.js';
import { useAsync } from '../../shared/lib/useAsync.js';
import { errorText } from '../../shared/lib/errors.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { admin, type AppointmentFilters } from '../api/index.js';
import type { AdminAppointment } from '../api/types.js';
import { Pagination } from '../components/Pagination.js';
import { CENTER_ZONE, addDays, todayInZone } from '../lib/dates.js';
import { useT } from '../i18n/useT.js';
import { BookDialog } from './appointments/BookDialog.js';
import { ManageDialog } from './appointments/ManageDialog.js';

const STATUSES = ['booked', 'completed', 'no_show', 'cancelled'] as const;
const PAGE_SIZE = 25;

interface FormState { from: string; to: string; departmentId: string; status: string; q: string; sort: 'asc' | 'desc' }

function defaults(): FormState {
  const today = todayInZone(CENTER_ZONE);
  return { from: today, to: addDays(today, 7), departmentId: '', status: '', q: '', sort: 'asc' };
}

const toFilters = (f: FormState): AppointmentFilters => ({
  ...(f.from ? { from: f.from } : {}), ...(f.to ? { to: f.to } : {}), ...(f.departmentId ? { departmentId: f.departmentId } : {}),
  ...(f.status ? { status: f.status } : {}), ...(f.q.trim() ? { q: f.q.trim() } : {}), sort: f.sort,
});

export function Appointments() {
  const t = useT();
  const i18n = useI18n();
  const [form, setForm] = useState<FormState>(defaults);
  const [applied, setApplied] = useState<FormState>(form);
  const [page, setPage] = useState(1);
  const [notice, setNotice] = useState<string | null>(null);
  const [managing, setManaging] = useState<AdminAppointment | null>(null);
  const [booking, setBooking] = useState(false);

  const depts = useAsync((signal) => admin.departments.list(signal), []);
  const list = useAsync((signal) => admin.appointments.list(toFilters(applied), i18n.locale, page, PAGE_SIZE, signal), [applied, page, i18n.locale]);
  const rangeInvalid = !!form.from && !!form.to && form.from > form.to;
  const deptName = (d: NonNullable<typeof depts.data>[number]) => d.translations[i18n.locale]?.name || Object.values(d.translations).find((x) => x?.name)?.name || d.slug;

  function search(e: FormEvent) {
    e.preventDefault();
    if (rangeInvalid) return;
    setNotice(null); setPage(1); setApplied({ ...form });
  }
  const set = <K extends keyof FormState>(k: K, v: FormState[K]) => setForm((f) => ({ ...f, [k]: v }));

  return (
    <div className="stack">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h1 style={{ margin: 0 }}>{t('admin.nav.appointments')}</h1>
        <Button onClick={() => { setNotice(null); setBooking(true); }}>{t('appts.book')}</Button>
      </div>

      <form onSubmit={search} className="stack" aria-label={t('appts.filter.legend')} noValidate>
        <div className="toolbar">
          <TextField label={t('appts.filter.from')} type="date" value={form.from} onChange={(e) => set('from', e.target.value)} />
          <TextField label={t('appts.filter.to')} type="date" value={form.to} onChange={(e) => set('to', e.target.value)} error={rangeInvalid ? t('appts.filter.rangeInvalid') : undefined} />
          <SelectField label={t('appts.filter.department')} value={form.departmentId} onChange={(e) => set('departmentId', e.target.value)}>
            <option value="">{t('appts.filter.allDepartments')}</option>
            {(depts.data ?? []).map((d) => <option key={d.id} value={d.id}>{deptName(d)}</option>)}
          </SelectField>
          <SelectField label={t('appts.filter.status')} value={form.status} onChange={(e) => set('status', e.target.value)}>
            <option value="">{t('appts.filter.allStatuses')}</option>
            {STATUSES.map((s) => <option key={s} value={s}>{t(`status.${s}`)}</option>)}
          </SelectField>
          <TextField label={t('appts.filter.search')} type="search" value={form.q} onChange={(e) => set('q', e.target.value)} maxLength={80} />
          <SelectField label={t('appts.filter.sort')} value={form.sort} onChange={(e) => set('sort', e.target.value as 'asc' | 'desc')}>
            <option value="asc">{t('appts.filter.sort.asc')}</option>
            <option value="desc">{t('appts.filter.sort.desc')}</option>
          </SelectField>
          <Button type="submit" disabled={rangeInvalid}>{t('common.search')}</Button>
          <Button variant="ghost" onClick={() => { const d = defaults(); setForm(d); setApplied(d); setPage(1); }}>{t('common.clear')}</Button>
        </div>
        {depts.status === 'error' ? <Alert tone="warning">{t('appts.deptsFailed')}</Alert> : null}
      </form>

      {notice ? <Alert tone="success">{notice}</Alert> : null}
      {list.status === 'loading' && !list.data ? <Loading /> : null}
      {list.status === 'error' ? <Alert tone="error">{t('admin.loadFailed')} {errorText(i18n, list.error)} <Button small variant="secondary" onClick={list.reload}>{t('common.retry')}</Button></Alert> : null}
      {list.data ? <p aria-live="polite" className="muted">{i18n.tn('admin.results', list.data.meta.total)}</p> : null}
      {list.data && list.data.data.length === 0 ? <EmptyState>{t('appts.empty')}</EmptyState> : null}
      {list.data && list.data.data.length > 0 ? (
        <div className="table-wrap">
          <table>
            <thead><tr>
              <th scope="col">{t('admin.col.date')}</th><th scope="col">{t('admin.col.time')}</th><th scope="col">{t('admin.col.patient')}</th>
              <th scope="col">{t('admin.col.department')}</th><th scope="col">{t('admin.col.service')}</th><th scope="col">{t('admin.col.status')}</th>
              <th scope="col">{t('appts.col.via')}</th><th scope="col">{t('admin.col.actions')}</th>
            </tr></thead>
            <tbody>
              {list.data.data.map((a) => (
                <tr key={a.id}>
                  <td>{i18n.date(a.date, 'short')}</td>
                  <td>{i18n.range(a.startTime, a.endTime)}</td>
                  <td><Link to={`/patients/${a.patient.id}`}>{a.patient.fullName}</Link><br /><span className="muted ltr">{a.patient.phone}</span></td>
                  <td>{a.department.name}</td>
                  <td>{a.service?.name ?? t('common.none')}</td>
                  <td><StatusBadge status={a.status} /></td>
                  <td>{t(`appts.via.${a.createdVia}`)}</td>
                  <td><Button small variant="secondary" aria-label={t('appts.manage.for', { patient: a.patient.fullName, date: i18n.date(a.date, 'short') })} onClick={() => { setNotice(null); setManaging(a); }}>{t('appts.manage')}</Button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}
      <Pagination meta={list.data?.meta} onPage={setPage} />

      <ManageDialog appointment={managing} onClose={() => setManaging(null)} onChanged={(m) => { setNotice(m); list.reload(); }} />
      <BookDialog open={booking} onClose={() => setBooking(false)} onBooked={() => list.reload()} />
    </div>
  );
}
