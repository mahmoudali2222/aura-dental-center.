import { useRef, useState, type FormEvent } from 'react';
import { Alert, Button, Dialog, SelectField, TextField } from '../../../shared/ui/index.js';
import { errorText } from '../../../shared/lib/errors.js';
import { toApiError } from '../../../shared/lib/useAsync.js';
import { useI18n } from '../../../shared/i18n/I18nProvider.js';
import { admin } from '../../api/index.js';
import type { AdminDepartment } from '../../api/types.js';
import { formErrors } from '../../lib/formErrors.js';
import { isIsoDate } from '../../lib/dates.js';
import { useT } from '../../i18n/useT.js';
import { pickName } from '../catalog/shared.js';

export function ClosureDialog({ open, today, departments, onClose, onSaved }: { open: boolean; today: string; departments: AdminDepartment[]; onClose: () => void; onSaved: (message: string) => void }) {
  const t = useT();
  return (
    <Dialog open={open} title={t('clo.form.title')} onClose={onClose}>
      {open ? <Form today={today} departments={departments} onClose={onClose} onSaved={onSaved} /> : null}
    </Dialog>
  );
}

/**
 * Closing a range that already holds booked appointments is a two-step action: the first attempt never carries the
 * acknowledgement. If the backend reports appointments, the form shows how many and asks for an explicit confirmation;
 * only then is the request repeated with `acknowledgeExistingAppointments`. Appointments are never cancelled by closing.
 */
function Form({ today, departments, onClose, onSaved }: { today: string; departments: AdminDepartment[]; onClose: () => void; onSaved: (message: string) => void }) {
  const t = useT();
  const i18n = useI18n();
  const [from, setFrom] = useState(today);
  const [to, setTo] = useState(today);
  const [departmentId, setDepartmentId] = useState('');
  const [reason, setReason] = useState('');
  const [existing, setExisting] = useState<number | null>(null);
  const [ack, setAck] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const running = useRef(false);

  const datesOk = isIsoDate(from) && isIsoDate(to);
  const rangeBad = datesOk && to < from;
  const ready = datesOk && !rangeBad;
  // Whatever is edited after the warning invalidates it: the count belongs to the old range.
  const edit = <T,>(set: (v: T) => void) => (v: T) => { set(v); setExisting(null); setAck(false); setError(null); };

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (running.current || !ready || (existing !== null && !ack)) return;
    running.current = true; setBusy(true); setError(null);
    try {
      await admin.settings.createClosure({
        dateFrom: from, dateTo: to, departmentId: departmentId || null, ...(reason.trim() ? { reason: reason.trim() } : {}),
        ...(existing !== null ? { acknowledgeExistingAppointments: true } : {}),
      });
      onSaved(t('clo.saved'));
      onClose();
    } catch (err) {
      const api = toApiError(err);
      if (api.code === 'CLOSURE_HAS_APPOINTMENTS') {
        const n = (api.details as { count?: unknown } | undefined)?.count;
        setExisting(typeof n === 'number' ? n : 0); setAck(false);
      } else setError(err);
    } finally { running.current = false; setBusy(false); }
  }

  const { fields, rest } = formErrors(i18n, error, { INVALID_RANGE: 'dateTo', DEPARTMENT_NOT_FOUND: 'departmentId' });
  return (
    <form onSubmit={submit} className="stack" noValidate>
      {rest ? <Alert tone="error">{errorText(i18n, rest)}</Alert> : null}
      <div className="toolbar">
        <TextField label={t('clo.from')} type="date" value={from} onChange={(e) => edit(setFrom)(e.target.value)} error={fields.dateFrom} />
        <TextField label={t('clo.to')} type="date" value={to} onChange={(e) => edit(setTo)(e.target.value)} error={rangeBad ? t('clo.range.invalid') : fields.dateTo} />
      </div>
      <SelectField label={t('clo.department')} value={departmentId} onChange={(e) => edit(setDepartmentId)(e.target.value)} error={fields.departmentId}>
        <option value="">{t('clo.scope.all')}</option>
        {departments.map((d) => <option key={d.id} value={d.id}>{pickName(d.translations, i18n.locale, d.slug)}</option>)}
      </SelectField>
      <TextField label={t('clo.reason')} optional hint={t('clo.reason.hint')} maxLength={300} value={reason} onChange={(e) => setReason(e.target.value)} error={fields.reason} />

      {existing !== null ? (
        <Alert tone="warning" title={i18n.tn('clo.ack', existing, { count: existing })}>
          <span>{t('clo.ack.note')}</span>
          <label className="check" style={{ marginBlockStart: 'var(--space-2)' }}>
            <input type="checkbox" checked={ack} onChange={(e) => setAck(e.target.checked)} /><span>{t('clo.ack.confirm')}</span>
          </label>
        </Alert>
      ) : null}

      <div className="row">
        <Button type="submit" loading={busy} disabled={!ready || (existing !== null && !ack)}>{existing !== null ? t('clo.ack.submit') : t('clo.submit')}</Button>
        <Button variant="ghost" onClick={onClose}>{t('common.cancel')}</Button>
      </div>
    </form>
  );
}
