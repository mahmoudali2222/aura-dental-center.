import { useRef, useState, type FormEvent } from 'react';
import { LOCALES, type Locale } from '../../../shared/api/types.js';
import { LOCALE_META } from '../../../shared/i18n/types.js';
import { Alert, Button, SelectField, TextField } from '../../../shared/ui/index.js';
import { errorText } from '../../../shared/lib/errors.js';
import { useI18n } from '../../../shared/i18n/I18nProvider.js';
import { admin } from '../../api/index.js';
import type { CenterSettings } from '../../api/types.js';
import { TranslationFields } from '../../components/TranslationFields.js';
import { WeekdayPicker, normalizeDays, sameDays } from '../../components/WeekdayPicker.js';
import { formErrors } from '../../lib/formErrors.js';
import { trToForm, type TrForm } from '../../lib/translations.js';
import { useT } from '../../i18n/useT.js';

const KEYS = ['name', 'address', 'introduction', 'hoursNote'] as const;
const CURRENCY_RE = /^[A-Z]{3}$/;
type Contact = 'phone' | 'whatsapp' | 'email' | 'mapUrl';
const CONTACT: Contact[] = ['phone', 'whatsapp', 'email', 'mapUrl'];

/**
 * The center profile. Only what was changed is sent (the backend leaves everything else alone). Per-language texts differ
 * from the catalog forms: an empty text is a legitimate value ("no hours note") and never removes a language.
 */
export function ProfileForm({ center, onSaved }: { center: CenterSettings; onSaved: (saved: CenterSettings) => void }) {
  const t = useT();
  const i18n = useI18n();
  const [contact, setContact] = useState<Record<Contact, string>>({ phone: center.phone ?? '', whatsapp: center.whatsapp ?? '', email: center.email ?? '', mapUrl: center.mapUrl ?? '' });
  const [defaultLocale, setDefaultLocale] = useState<Locale>(center.defaultLocale);
  const [currency, setCurrency] = useState(center.currency);
  const [horizon, setHorizon] = useState(String(center.bookingHorizonDays));
  const [days, setDays] = useState<number[]>(normalizeDays(center.workingDays));
  const [tr, setTr] = useState<TrForm>(() => trToForm(center.translations, KEYS));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const running = useRef(false);

  const horizonOk = /^\d{1,3}$/.test(horizon.trim()) && Number(horizon) >= 1 && Number(horizon) <= 365;
  const currencyOk = CURRENCY_RE.test(currency);
  const daysOk = days.length > 0;

  // What differs from the saved profile; nothing to send means nothing to save.
  const body: Parameters<typeof admin.settings.saveCenter>[0] = {};
  for (const k of CONTACT) {
    const was = (center[k] ?? '').trim();
    const now = contact[k].trim();
    if (now !== was) body[k] = now === '' ? null : now;
  }
  if (defaultLocale !== center.defaultLocale) body.defaultLocale = defaultLocale;
  if (currency !== center.currency) body.currency = currency;
  if (horizonOk && Number(horizon) !== center.bookingHorizonDays) body.bookingHorizonDays = Number(horizon);
  if (daysOk && !sameDays(days, center.workingDays)) body.workingDays = normalizeDays(days);
  const translations: NonNullable<typeof body.translations> = {};
  for (const l of LOCALES) {
    const changed: Partial<Record<(typeof KEYS)[number], string>> = {};
    for (const k of KEYS) {
      const was = (center.translations[l]?.[k] ?? '').trim();
      const now = (tr[l][k] ?? '').trim();
      if (now !== was) changed[k] = now;
    }
    if (Object.keys(changed).length > 0) translations[l] = changed;
  }
  if (Object.keys(translations).length > 0) body.translations = translations;
  const dirty = Object.keys(body).length > 0;
  const valid = horizonOk && currencyOk && daysOk;
  const noAddress = LOCALES.every((l) => (tr[l].address ?? '').trim() === '');

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (running.current || !dirty || !valid) return;
    running.current = true; setBusy(true); setError(null);
    try { onSaved(await admin.settings.saveCenter(body)); }
    catch (err) { setError(err); }
    finally { running.current = false; setBusy(false); }
  }

  const { fields, rest } = formErrors(i18n, error, { INVALID_EMAIL: 'email', INVALID_URL: 'mapUrl', INVALID_CURRENCY: 'currency', INVALID_HORIZON: 'bookingHorizonDays', AT_LEAST_ONE_WORKING_DAY: 'workingDays' });
  const setC = (k: Contact) => (e: { target: { value: string } }) => setContact({ ...contact, [k]: e.target.value });

  return (
    <form onSubmit={submit} className="stack" noValidate>
      {rest ? <Alert tone="error">{errorText(i18n, rest)}</Alert> : null}
      {noAddress ? <Alert tone="warning">{t('set.addressMissing')}</Alert> : null}

      <fieldset className="stack">
        <legend>{t('set.section.contact')}</legend>
        <div className="toolbar">
          <TextField label={t('set.phone')} type="tel" dir="ltr" autoComplete="off" maxLength={40} value={contact.phone} onChange={setC('phone')} error={fields.phone} />
          <TextField label={t('set.whatsapp')} type="tel" dir="ltr" autoComplete="off" maxLength={40} value={contact.whatsapp} onChange={setC('whatsapp')} error={fields.whatsapp} />
        </div>
        <TextField label={t('set.email')} type="email" dir="ltr" autoComplete="off" maxLength={160} value={contact.email} onChange={setC('email')} error={fields.email} />
        <TextField label={t('set.mapUrl')} type="url" dir="ltr" hint={t('set.mapUrl.hint')} maxLength={500} value={contact.mapUrl} onChange={setC('mapUrl')} error={fields.mapUrl} />
      </fieldset>

      <TranslationFields legend={t('set.tr.legend')} value={tr} onChange={setTr} errors={fields}
        fields={[
          { key: 'name', label: t('set.tr.name'), maxLength: 160 },
          { key: 'address', label: t('set.tr.address'), hint: t('set.tr.address.hint'), multiline: true, maxLength: 500 },
          { key: 'introduction', label: t('set.tr.introduction'), multiline: true, maxLength: 4000 },
          { key: 'hoursNote', label: t('set.tr.hoursNote'), maxLength: 500 },
        ]} />

      <fieldset className="stack">
        <legend>{t('set.section.booking')}</legend>
        <div className="toolbar">
          <SelectField label={t('set.defaultLocale')} hint={t('set.defaultLocale.hint')} value={defaultLocale} onChange={(e) => setDefaultLocale(e.target.value as Locale)} error={fields.defaultLocale}>
            {LOCALES.map((l) => <option key={l} value={l}>{LOCALE_META[l].nativeName}</option>)}
          </SelectField>
          <TextField label={t('set.currency')} hint={t('set.currency.hint')} dir="ltr" autoCapitalize="characters" maxLength={3} value={currency} onChange={(e) => setCurrency(e.target.value.toUpperCase())}
            error={currencyOk ? fields.currency : t('err.INVALID_CURRENCY')} />
          <TextField label={t('set.horizon')} hint={t('set.horizon.hint')} inputMode="numeric" dir="ltr" value={horizon} onChange={(e) => setHorizon(e.target.value)}
            error={horizonOk ? fields.bookingHorizonDays : t('err.INVALID_HORIZON')} />
        </div>
        <WeekdayPicker legend={t('set.workingDays')} hint={t('set.workingDays.hint')} value={days} onChange={setDays}
          error={!daysOk ? t('err.AT_LEAST_ONE_WORKING_DAY') : fields.workingDays} />
      </fieldset>

      <div className="row">
        <Button type="submit" loading={busy} disabled={!dirty || !valid}>{t('set.save')}</Button>
        {!dirty ? <span className="muted">{t('set.unchanged')}</span> : null}
      </div>
    </form>
  );
}
