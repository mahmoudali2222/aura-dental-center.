import { useState } from 'react';
import { Alert, Loading } from '../../../shared/ui/index.js';
import { useAsync } from '../../../shared/lib/useAsync.js';
import { errorText } from '../../../shared/lib/errors.js';
import { useI18n } from '../../../shared/i18n/I18nProvider.js';
import { admin } from '../../api/index.js';
import { useAction } from '../../lib/useAction.js';
import { useT } from '../../i18n/useT.js';

/** The four daily 2-hour slots. Only whether each is offered can change; times and length are fixed by design. */
export function SlotsCard() {
  const t = useT();
  const i18n = useI18n();
  const list = useAsync((signal) => admin.settings.slots(signal), []);
  const [notice, setNotice] = useState<string | null>(null);
  const change = useAction((n: number, on: boolean) => admin.settings.setSlot(n, on));

  async function toggle(n: number, on: boolean) {
    setNotice(null);
    if (await change.attempt(n, on)) { setNotice(t(on ? 'slot.saved.on' : 'slot.saved.off', { number: n })); list.reload(); }
  }

  return (
    <section className="stack card" aria-labelledby="slots-title">
      <h2 id="slots-title" style={{ margin: 0 }}>{t('slot.title')}</h2>
      <p className="muted" style={{ margin: 0 }}>{t('slot.intro')}</p>
      {notice ? <Alert tone="success">{notice}</Alert> : null}
      {change.error ? <Alert tone="error">{errorText(i18n, change.error)}</Alert> : null}
      {list.status === 'loading' && !list.data ? <Loading /> : null}
      {list.status === 'error' ? <Alert tone="error">{t('admin.loadFailed')} {errorText(i18n, list.error)}</Alert> : null}
      <div className="stack">
        {(list.data ?? []).map((s) => (
          <label key={s.slotNumber} className="check">
            <input type="checkbox" checked={s.isActive} disabled={change.busy} onChange={(e) => void toggle(s.slotNumber, e.target.checked)} />
            <span>{t('slot.label', { number: s.slotNumber, range: i18n.range(s.startTime, s.endTime) })}</span>
          </label>
        ))}
      </div>
    </section>
  );
}
