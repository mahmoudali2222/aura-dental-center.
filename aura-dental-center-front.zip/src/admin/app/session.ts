import { createSession } from '../../shared/auth/createSession.js';
import type { AdminPrincipal } from '../../shared/api/admin.js';
import { auth, http } from '../api/index.js';

export interface AdminLoginInput { username: string; password: string }

export const { SessionProvider, useSession } = createSession<AdminPrincipal, AdminLoginInput>({
  http,
  restore: async (signal) => {
    const r = await auth.me(signal);
    return { user: r.admin, csrfToken: r.csrfToken };
  },
  login: async (input) => {
    const r = await auth.login(input);
    return { user: r.admin, csrfToken: r.csrfToken };
  },
  logout: () => auth.logout(),
});
