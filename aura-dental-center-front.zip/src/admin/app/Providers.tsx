import type { ReactNode } from 'react';
import { I18nProvider } from '../../shared/i18n/I18nProvider.js';
import { adminMessages } from '../i18n/messages.js';
import { SessionProvider } from './session.js';

export const LOCALE_STORAGE_KEY = 'dc.admin.locale';

/** Language -> session. The router is supplied by the caller (BrowserRouter in the app, MemoryRouter in tests). */
export function AdminProviders({ children }: { children: ReactNode }) {
  return (
    <I18nProvider messages={adminMessages} storageKey={LOCALE_STORAGE_KEY}>
      <SessionProvider>{children}</SessionProvider>
    </I18nProvider>
  );
}
