import type { PageMeta } from '../../shared/api/http.js';
import { Button } from '../../shared/ui/index.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';

export function Pagination({ meta, onPage }: { meta: PageMeta | undefined; onPage: (page: number) => void }) {
  const { t } = useI18n();
  if (!meta || meta.totalPages <= 1) return null;
  return (
    <nav className="row pagination" aria-label={t('common.page', { page: meta.page, total: meta.totalPages })}>
      <Button variant="secondary" small disabled={meta.page <= 1} onClick={() => onPage(meta.page - 1)}>{t('common.previous')}</Button>
      <span>{t('common.page', { page: meta.page, total: meta.totalPages })}</span>
      <Button variant="secondary" small disabled={meta.page >= meta.totalPages} onClick={() => onPage(meta.page + 1)}>{t('common.next')}</Button>
    </nav>
  );
}
