import type { ReactNode } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { Loading } from '../../shared/ui/index.js';
import { useSession } from '../app/session.js';

/** Protected pages: wait for the session check, then sign in first, and change the initial password before anything else. */
export function RequireAdmin({ children }: { children: ReactNode }) {
  const { status, user } = useSession();
  const location = useLocation();
  if (status === 'loading') return <Loading />;
  if (status === 'anonymous') return <Navigate to="/login" replace state={{ from: `${location.pathname}${location.search}` }} />;
  if (user?.mustChangePassword && location.pathname !== '/change-password') return <Navigate to="/change-password" replace />;
  return <>{children}</>;
}
