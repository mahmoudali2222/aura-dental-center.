import { LOCALES, type Locale } from '../../shared/api/types.js';
import { LOCALE_META } from '../../shared/i18n/types.js';
import { TextAreaField, TextField } from '../../shared/ui/index.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import type { TrForm } from '../lib/translations.js';

export interface TrFieldDef {
  key: string;
  label: string;
  multiline?: boolean;
  /** The first field of a language is its mandatory one: leaving it empty removes that language. */
  hint?: string;
  maxLength?: number;
}

/**
 * One labelled group of fields per language, each named in its own language and typed in its own direction, so staff always
 * know which text is shown to whom. `errors` uses the backend's paths ("translations.ar.name").
 */
export function TranslationFields({ value, onChange, fields, errors = {}, legend }: {
  value: TrForm;
  onChange: (next: TrForm) => void;
  fields: TrFieldDef[];
  errors?: Record<string, string>;
  legend: string;
}) {
  const { t } = useI18n();
  const set = (l: Locale, key: string, v: string) => onChange({ ...value, [l]: { ...value[l], [key]: v } });
  return (
    <fieldset className="stack translation-fields">
      <legend>{legend}</legend>
      <p className="muted">{t('admin.tr.hint')}</p>
      <div className="translation-grid">
        {LOCALES.map((l) => (
          <fieldset key={l} className="card stack" lang={l} dir={LOCALE_META[l].dir}>
            <legend lang={l}>{LOCALE_META[l].nativeName}</legend>
            {fields.map((f) => {
              const common = {
                label: f.label, hint: f.hint, maxLength: f.maxLength, lang: l, dir: LOCALE_META[l].dir, name: `${l}-${f.key}`,
                error: errors[`translations.${l}.${f.key}`],
              };
              return f.multiline
                ? <TextAreaField key={f.key} {...common} value={value[l][f.key] ?? ''} onChange={(e) => set(l, f.key, e.target.value)} />
                : <TextField key={f.key} {...common} value={value[l][f.key] ?? ''} onChange={(e) => set(l, f.key, e.target.value)} />;
            })}
          </fieldset>
        ))}
      </div>
    </fieldset>
  );
}
