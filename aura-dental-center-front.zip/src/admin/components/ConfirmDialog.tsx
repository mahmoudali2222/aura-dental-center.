import type { ReactNode } from 'react';
import { Alert, Button, Dialog } from '../../shared/ui/index.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { errorText } from '../../shared/lib/errors.js';

/** "Are you sure?" for actions that cannot be undone or that affect a patient. Shows the failure reason inside the dialog. */
export function ConfirmDialog({ open, title, children, confirmLabel, cancelLabel, danger, busy, error, errorOverrides, onConfirm, onClose, disabled }: {
  open: boolean;
  title: string;
  children?: ReactNode;
  confirmLabel: string;
  cancelLabel?: string;
  danger?: boolean;
  busy?: boolean;
  error?: unknown;
  errorOverrides?: Record<string, string>;
  disabled?: boolean;
  onConfirm: () => void;
  onClose: () => void;
}) {
  const i18n = useI18n();
  return (
    <Dialog open={open} title={title} onClose={onClose}>
      <div className="stack">
        {children}
        {error ? <Alert tone="error">{errorText(i18n, error, errorOverrides)}</Alert> : null}
        <div className="row">
          <Button variant={danger ? 'danger' : 'primary'} loading={busy} disabled={disabled} onClick={onConfirm}>{confirmLabel}</Button>
          <Button variant="ghost" onClick={onClose}>{cancelLabel ?? i18n.t('common.cancel')}</Button>
        </div>
      </div>
    </Dialog>
  );
}
