import { useState } from 'react';
import { Alert, Button, Dialog, EmptyState, Loading, StatusBadge } from '../../shared/ui/index.js';
import { useAsync } from '../../shared/lib/useAsync.js';
import { errorText } from '../../shared/lib/errors.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import type { Appointment } from '../../shared/api/types.js';
import { patientCalls } from '../api.js';
import { useCenter } from '../app/center.js';
import { PrecautionsCard } from '../components/PrecautionsCard.js';
import { SlotPicker, type SlotChoice } from '../components/SlotPicker.js';
import { dayLeaf } from '../lib/dates.js';
import { useT } from '../i18n/useT.js';

export function Appointments() {
  const t = useT();
  const i18n = useI18n();
  const [scope, setScope] = useState<'upcoming' | 'history'>('upcoming');
  const [notice, setNotice] = useState<string | null>(null);
  const list = useAsync((signal) => patientCalls.appointments(scope, i18n.locale, 1, 50, signal), [scope, i18n.locale]);

  return (
    <div className="page container">
      <header className="page__head">
        <h1>{t('appts.title')}</h1>
        <p>{t('appts.lead')}</p>
      </header>
      <div className="segmented" role="group" aria-label={t('appts.title')}>
        <button type="button" aria-pressed={scope === 'upcoming'} onClick={() => { setScope('upcoming'); setNotice(null); }}>{t('appts.upcoming')}</button>
        <button type="button" aria-pressed={scope === 'history'} onClick={() => { setScope('history'); setNotice(null); }}>{t('appts.history')}</button>
      </div>
      <div className="appts">
        {notice ? <Alert tone="success">{notice}</Alert> : null}
        {list.status === 'loading' && !list.data ? <Loading /> : null}
        {list.status === 'error' ? <Alert tone="error">{t('appts.loadFailed')} {errorText(i18n, list.error)} <Button small variant="secondary" onClick={list.reload}>{t('common.retry')}</Button></Alert> : null}
        {list.data && list.data.data.length === 0 ? <EmptyState>{scope === 'upcoming' ? t('appts.empty.upcoming') : t('appts.empty.history')}</EmptyState> : null}
        <ul className="appt-list">
          {(list.data?.data ?? []).map((a) => (
            <li key={a.id}>
              <AppointmentCard appointment={a} onChanged={(msg) => { setNotice(msg); list.reload(); }} />
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function AppointmentCard({ appointment: a, onChanged }: { appointment: Appointment; onChanged: (message: string) => void }) {
  const t = useT();
  const i18n = useI18n();
  const { center } = useCenter();
  const [mode, setMode] = useState<'idle' | 'cancel' | 'reschedule' | 'before'>('idle');
  const [choice, setChoice] = useState<SlotChoice | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const active = a.status === 'booked';
  const zone = center?.timezone ?? 'Africa/Cairo';
  const leaf = dayLeaf(a.date, i18n.locale);

  async function cancel() {
    setBusy(true); setError(null);
    try { await patientCalls.cancel(a.id, i18n.locale); setMode('idle'); onChanged(t('appts.cancelled')); }
    catch (err) { setError(err); } finally { setBusy(false); }
  }
  async function reschedule() {
    if (!choice) return;
    setBusy(true); setError(null);
    try { await patientCalls.reschedule(a.id, { date: choice.date, slotNumber: choice.slotNumber }, i18n.locale); setMode('idle'); setChoice(null); onChanged(t('appts.rescheduled')); }
    catch (err) { setError(err); setChoice(null); setRefreshKey((k) => k + 1); } finally { setBusy(false); }
  }

  return (
    <article className={`appt${active ? '' : ' appt--past'}`} aria-label={`${a.department.name} ${i18n.date(a.date)}`}>
      <div className="leaf" aria-hidden="true">
        <span className="leaf__month">{leaf.month}</span>
        <span className="leaf__day tabular">{leaf.day}</span>
        <span className="leaf__weekday">{leaf.weekday}</span>
      </div>
      <div className="appt__body">
        <div className="appt__top">
          <h2>{a.department.name}</h2>
          <StatusBadge status={a.status} />
        </div>
        <p className="appt__when"><strong>{i18n.date(a.date)}</strong> · {i18n.range(a.startTime, a.endTime)}{a.endsNextDay ? ` (${t('common.nextDay')})` : ''}</p>
        <ul className="appt__meta">
          {a.dentist?.name ? <li>{t('appts.with', { dentist: a.dentist.name })}</li> : null}
          {a.service?.name ? <li>{t('appts.service', { service: a.service.name })}</li> : null}
          <li>{t(`appts.via.${a.createdVia}`)}</li>
        </ul>
        {active ? (
          a.selfService.canCancel || a.selfService.canReschedule ? (
            <>
              {a.selfService.deadline ? <p className="appt__deadline muted">{t('appts.deadline', { when: i18n.instant(a.selfService.deadline, zone) })}</p> : null}
              <div className="appt__actions">
                <Button variant="secondary" small onClick={() => { setMode('reschedule'); setError(null); }}>{t('appts.reschedule')}</Button>
                <Button variant="ghost" small onClick={() => { setMode('cancel'); setError(null); }}>{t('appts.cancel')}</Button>
                <Button variant="ghost" small onClick={() => setMode('before')}>{t('appts.before')}</Button>
              </div>
            </>
          ) : (
            <>
              <Alert tone="warning">{t('appts.locked')}</Alert>
              <div className="appt__actions"><Button variant="ghost" small onClick={() => setMode('before')}>{t('appts.before')}</Button></div>
            </>
          )
        ) : null}
      </div>

      <Dialog open={mode === 'cancel'} title={t('appts.cancel.title')} onClose={() => setMode('idle')}>
        <p>{t('appts.cancel.text')}</p>
        {error ? <Alert tone="error">{errorText(i18n, error)}</Alert> : null}
        <div className="dialog-actions">
          <Button variant="danger" loading={busy} onClick={() => void cancel()}>{t('appts.cancel.confirm')}</Button>
          <Button variant="ghost" onClick={() => setMode('idle')}>{t('appts.cancel.keep')}</Button>
        </div>
      </Dialog>

      <Dialog open={mode === 'before'} title={t('appts.before')} onClose={() => setMode('idle')}>
        <PrecautionsCard heading={false} />
        <div className="dialog-actions"><Button variant="ghost" onClick={() => setMode('idle')}>{t('common.close')}</Button></div>
      </Dialog>

      {mode === 'reschedule' ? (
        <section className="appt__reschedule" aria-label={t('appts.reschedule.title')}>
          <h3>{t('appts.reschedule.title')}</h3>
          <p className="muted">{t('appts.reschedule.current', { when: `${i18n.date(a.date)} · ${i18n.range(a.startTime, a.endTime)}` })}</p>
          <SlotPicker slug={a.department.slug} value={choice} onChange={setChoice} refreshKey={refreshKey} />
          {error ? <Alert tone="error">{errorText(i18n, error)}</Alert> : null}
          <div className="appt__actions">
            <Button loading={busy} disabled={!choice} onClick={() => void reschedule()}>{t('appts.reschedule.confirm')}</Button>
            <Button variant="ghost" onClick={() => { setMode('idle'); setChoice(null); }}>{t('common.cancel')}</Button>
          </div>
        </section>
      ) : null}
    </article>
  );
}
