import { useEffect, useState, type FormEvent } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Alert, Button, Loading, TextAreaField } from '../../shared/ui/index.js';
import { useAsync } from '../../shared/lib/useAsync.js';
import { errorText, fieldErrors } from '../../shared/lib/errors.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import type { Appointment } from '../../shared/api/types.js';
import { patientCalls, pub } from '../api.js';
import { useCenter } from '../app/center.js';
import { PrecautionsCard } from '../components/PrecautionsCard.js';
import { SlotPicker, type SlotChoice } from '../components/SlotPicker.js';
import { WorkingDays } from '../components/WorkingDays.js';
import { CheckIcon } from '../components/icons.js';
import { useT } from '../i18n/useT.js';

/** Codes after which the chosen time is certainly stale: drop it and reload availability. */
const STALE_SLOT = new Set(['SLOT_UNAVAILABLE', 'DAILY_CAPACITY_REACHED', 'SLOT_IN_PAST', 'DATE_CLOSED', 'BEYOND_BOOKING_HORIZON']);

/**
 * Booking on one calm page: department, (optional) service, day and time, then a short review. The summary beside it (below the
 * steps on a phone) follows the choices and holds the confirm button. Everything offered, including which days are open, comes from the API.
 */
export function Book() {
  const t = useT();
  const i18n = useI18n();
  const { center } = useCenter();
  const [params, setParams] = useSearchParams();
  const slug = params.get('department') ?? '';
  const depts = useAsync((signal) => pub.departments(i18n.locale, signal), [i18n.locale]);
  const detail = useAsync((signal) => (slug ? pub.department(slug, i18n.locale, signal) : Promise.resolve(null)), [slug, i18n.locale]);
  const [serviceId, setServiceId] = useState('');
  const [choice, setChoice] = useState<SlotChoice | null>(null);
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [booked, setBooked] = useState<Appointment | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => { setServiceId(''); setChoice(null); setError(null); }, [slug]);

  const bookable = (depts.data ?? []).filter((d) => d.bookable);
  const department = detail.data && detail.data.bookable ? detail.data : null;
  const service = department?.services.find((s) => s.id === serviceId) ?? null;

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!department || !choice || busy) return;
    setBusy(true); setError(null);
    try {
      const appt = await patientCalls.book({ departmentId: department.id, serviceId: serviceId || null, date: choice.date, slotNumber: choice.slotNumber, patientNote: note.trim() || undefined }, i18n.locale);
      setBooked(appt);
    } catch (err) {
      setError(err);
      if (err instanceof Error && 'code' in err && STALE_SLOT.has((err as { code: string }).code)) { setChoice(null); setRefreshKey((k) => k + 1); }
    } finally { setBusy(false); }
  }

  if (booked) {
    return (
      <div className="page container done" aria-live="polite">
        <div className="done__head">
          <span className="done__mark" aria-hidden="true"><CheckIcon size={26} /></span>
          <h1>{t('book.success')}</h1>
          <p className="done__summary">{t('book.summary', { department: booked.department.name, date: i18n.date(booked.date), time: i18n.range(booked.startTime, booked.endTime) })}</p>
          <p className="muted">{t('book.policy')}</p>
          <div className="done__actions">
            <Link to="/appointments" className="btn">{t('book.viewAppointments')}</Link>
            <Button variant="ghost" onClick={() => { setBooked(null); setChoice(null); setNote(''); setRefreshKey((k) => k + 1); }}>{t('book.another')}</Button>
          </div>
        </div>
        <div className="done__before"><PrecautionsCard /></div>
      </div>
    );
  }

  const f = fieldErrors(i18n, error);
  let n = 0;
  const stepNo = () => <span className="step__n tabular" aria-hidden="true">{++n}</span>;
  return (
    <form onSubmit={submit} className="page container booking" noValidate>
      <header className="page__head">
        <h1>{t('book.title')}</h1>
        <p>{t('book.policy')}</p>
      </header>
      <div className="booking__grid">
        <div className="booking__steps">
          <section className="step" aria-labelledby="step-department">
            <h2 id="step-department" className="step__title">{stepNo()}{t('book.step.department')}</h2>
            {depts.status === 'loading' && !depts.data ? <Loading /> : null}
            {depts.status === 'error' && !depts.data ? <Alert tone="error">{errorText(i18n, depts.error)} <Button small variant="secondary" onClick={depts.reload}>{t('common.retry')}</Button></Alert> : null}
            {depts.data ? (
              <div className="choices" role="radiogroup" aria-label={t('book.department')}>
                {bookable.map((d) => (
                  <label key={d.id} className={`choice${slug === d.slug ? ' is-selected' : ''}`}>
                    <input type="radio" name="department" value={d.slug} className="visually-hidden" checked={slug === d.slug} onChange={() => setParams({ department: d.slug }, { replace: true })} />
                    <span>{d.name}</span>
                  </label>
                ))}
              </div>
            ) : null}
            {slug && detail.status === 'loading' && !detail.data ? <Loading /> : null}
            {slug && detail.data && !detail.data.bookable ? <Alert tone="info">{t('departments.notBookable')}</Alert> : null}
            {slug && detail.status === 'error' && !detail.data ? <Alert tone="error">{errorText(i18n, detail.error)}</Alert> : null}
            {department ? <WorkingDays days={department.workingDays} centerDays={center?.workingDays} text /> : null}
          </section>

          {department ? (
            <>
              {department.services.length > 0 ? (
                <section className="step" aria-labelledby="step-service">
                  <h2 id="step-service" className="step__title">{stepNo()}{t('book.step.service')} <span className="muted step__opt">({t('common.optional')})</span></h2>
                  <div className="choices" role="radiogroup" aria-label={t('book.service')}>
                    <label className={`choice${serviceId === '' ? ' is-selected' : ''}`}>
                      <input type="radio" name="service" value="" className="visually-hidden" checked={serviceId === ''} onChange={() => setServiceId('')} />
                      <span>{t('book.service.none')}</span>
                    </label>
                    {department.services.map((s) => (
                      <label key={s.id} className={`choice${serviceId === s.id ? ' is-selected' : ''}`}>
                        <input type="radio" name="service" value={s.id} className="visually-hidden" checked={serviceId === s.id} onChange={() => setServiceId(s.id)} />
                        <span>{s.name}</span>
                      </label>
                    ))}
                  </div>
                  {f.serviceId ? <p className="field__error">{f.serviceId}</p> : null}
                </section>
              ) : null}

              <section className="step" aria-labelledby="step-when">
                <h2 id="step-when" className="step__title">{stepNo()}{t('book.step.when')}</h2>
                <SlotPicker slug={department.slug} value={choice} onChange={setChoice} refreshKey={refreshKey} />
                <div><Button variant="ghost" small onClick={() => setRefreshKey((k) => k + 1)}>{t('book.refresh')}</Button></div>
              </section>

              <section className="step" aria-labelledby="step-confirm">
                <h2 id="step-confirm" className="step__title">{stepNo()}{t('book.step.confirm')}</h2>
                <TextAreaField label={t('book.note')} optional hint={t('book.note.hint')} maxLength={500} value={note} onChange={(e) => setNote(e.target.value)} error={f.patientNote} />
                <PrecautionsCard />
              </section>
            </>
          ) : null}
        </div>

        <aside className="summary" aria-labelledby="summary-title">
          <h2 id="summary-title" className="summary__title">{t('book.summary.title')}</h2>
          {department && choice ? (
            <dl className="summary__list">
              <div><dt>{t('book.department')}</dt><dd>{department.name}</dd></div>
              {department.dentist ? <div className="summary__extra"><dt>{t('departments.dentist')}</dt><dd>{department.dentist.name}</dd></div> : null}
              {service ? <div className="summary__extra"><dt>{t('book.service')}</dt><dd>{service.name}</dd></div> : null}
              <div><dt>{t('book.summary.when')}</dt><dd>{i18n.date(choice.date)}<br />{i18n.range(choice.startTime, choice.endTime)}{choice.endsNextDay ? ` (${t('common.nextDay')})` : ''}</dd></div>
            </dl>
          ) : <p className="summary__empty muted">{t('book.summary.empty')}</p>}
          {department && choice ? <p className="visually-hidden">{t('book.summary', { department: department.name, date: i18n.date(choice.date), time: i18n.range(choice.startTime, choice.endTime) })}</p> : null}
          {error ? <Alert tone="error">{errorText(i18n, error)}</Alert> : null}
          <div className="summary__actions">
            <Button type="submit" loading={busy} disabled={!choice || !department} className="btn--lg btn--block">{t('book.submit')}</Button>
          </div>
        </aside>
      </div>
    </form>
  );
}
