import { Alert, Button, EmptyState, Loading } from '../../shared/ui/index.js';
import { useAsync } from '../../shared/lib/useAsync.js';
import { errorText } from '../../shared/lib/errors.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { pub } from '../api.js';
import { useCenter } from '../app/center.js';
import { DepartmentRow } from '../components/DepartmentRow.js';
import { useT } from '../i18n/useT.js';

export function Departments() {
  const t = useT();
  const i18n = useI18n();
  const { center } = useCenter();
  const depts = useAsync((signal) => pub.departments(i18n.locale, signal), [i18n.locale]);
  return (
    <div className="page container">
      <header className="page__head">
        <h1>{t('departments.title')}</h1>
        <p>{t('departments.intro')}</p>
      </header>
      {depts.status === 'loading' && !depts.data ? <Loading /> : null}
      {depts.status === 'error' && !depts.data ? <Alert tone="error">{errorText(i18n, depts.error)} <Button small variant="secondary" onClick={depts.reload}>{t('common.retry')}</Button></Alert> : null}
      {depts.data && depts.data.length === 0 ? <EmptyState>{t('departments.empty')}</EmptyState> : null}
      {depts.data && depts.data.length > 0 ? <ul className="dept-list">{depts.data.map((d) => <DepartmentRow key={d.id} department={d} center={center} detailed />)}</ul> : null}
    </div>
  );
}
