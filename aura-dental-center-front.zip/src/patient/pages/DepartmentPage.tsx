import { Link, useParams } from 'react-router-dom';
import { Alert, AssetImage, Button, Loading } from '../../shared/ui/index.js';
import { useAsync } from '../../shared/lib/useAsync.js';
import { errorText } from '../../shared/lib/errors.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { pub } from '../api.js';
import { useCenter } from '../app/center.js';
import { useT } from '../i18n/useT.js';
import { WorkingDays } from '../components/WorkingDays.js';
import { ChevronStart } from '../components/icons.js';

/** One template for every department: everything on the page comes from the backend, nothing is hardcoded per department. */
export function DepartmentPage() {
  const { slug = '' } = useParams();
  const t = useT();
  const i18n = useI18n();
  const { center } = useCenter();
  const d = useAsync((signal) => pub.department(slug, i18n.locale, signal), [slug, i18n.locale]);

  if (d.status === 'loading' && !d.data) return <div className="page container"><Loading /></div>;
  if (d.status === 'error' && !d.data) {
    return (
      <div className="page container stack">
        {d.error.code === 'DEPARTMENT_NOT_FOUND'
          ? <><Alert tone="error">{t('departments.notFound')}</Alert><Link to="/departments">{t('departments.all')}</Link></>
          : <Alert tone="error">{errorText(i18n, d.error)} <Button small variant="secondary" onClick={d.reload}>{t('common.retry')}</Button></Alert>}
      </div>
    );
  }
  const dep = d.data!;
  return (
    <article className="page container dept">
      <Link to="/departments" className="back-link"><ChevronStart size={18} />{t('departments.all')}</Link>
      <header className="dept__head">
        <h1>{dep.name}</h1>
        <p className="dept__lead">{dep.description}</p>
      </header>
      <div className="dept__layout">
        <div className="dept__main">
          {dep.imagePath ? (
            <section className="example" aria-labelledby="example-h">
              <h2 id="example-h">{t('departments.example')}</h2>
              <p className="muted">{t('departments.exampleLead')}</p>
              <figure className="example__figure">
                <AssetImage src={dep.imagePath} alt={t('departments.exampleAlt', { department: dep.name })} className="example__img" />
              </figure>
            </section>
          ) : null}

          <section aria-labelledby="services-h" className="dept__section">
            <h2 id="services-h">{t('departments.services')}</h2>
            {dep.services.length === 0 ? <p className="muted">{t('departments.noServices')}</p> : (
              <ul className="service-list">
                {dep.services.map((s) => (
                  <li key={s.id} className="service">
                    <div className="service__main">
                      <h3>{s.name}{s.isSample ? <> <span className="badge">{t('common.sample')}</span></> : null}</h3>
                      {s.description ? <p>{s.description}</p> : null}
                    </div>
                    <p className="service__price">{s.price !== null && s.currency ? `${t('departments.price')}: ${i18n.price(s.price, s.currency)}` : t('departments.priceOnRequest')}</p>
                  </li>
                ))}
              </ul>
            )}
          </section>

          {dep.gallery.length > 0 ? (
            <section aria-labelledby="gallery-h" className="dept__section">
              <h2 id="gallery-h">{t('departments.gallery')}</h2>
              <div className="gallery">
                {dep.gallery.map((g) => (
                  <figure key={g.id} className="gallery__case">
                    <div className="gallery__pair">
                      <figure><AssetImage src={g.beforeImagePath} alt={g.altBefore || t('departments.before')} /><figcaption>{t('departments.before')}</figcaption></figure>
                      <figure><AssetImage src={g.afterImagePath} alt={g.altAfter || t('departments.after')} /><figcaption>{t('departments.after')}</figcaption></figure>
                    </div>
                    <figcaption><strong>{g.title}</strong> {g.description}{g.isSample ? <span className="muted gallery__note">{t('departments.gallerySampleNote')}</span> : null}</figcaption>
                  </figure>
                ))}
              </div>
            </section>
          ) : null}
        </div>

        <aside className="dept__aside">
          <section className="card book-card" aria-labelledby="bookcard-h">
            <h2 id="bookcard-h">{t('departments.bookCard.title')}</h2>
            <p className="muted">{t('departments.bookCard.text')}</p>
            <WorkingDays days={dep.workingDays} centerDays={center?.workingDays} text />
            {dep.bookable
              ? <Link to={`/book?department=${encodeURIComponent(dep.slug)}`} className="btn btn--block">{t('departments.book')}</Link>
              : <Alert tone="info">{t('departments.notBookable')}</Alert>}
          </section>
          {dep.dentist ? (
            <section aria-labelledby="dentist-h" className="card dentist">
              <h2 id="dentist-h">{t('departments.dentist')}</h2>
              <div className="dentist__row">
                <AssetImage src={dep.dentist.photoPath} alt={dep.dentist.name} width={72} height={72} className="dentist__photo" />
                <div>
                  <strong>{dep.dentist.name}</strong>{dep.dentist.isSample ? <> <span className="badge">{t('common.sample')}</span></> : null}
                  {dep.dentist.bio ? <p className="muted dentist__bio">{dep.dentist.bio}</p> : null}
                </div>
              </div>
            </section>
          ) : null}
        </aside>
      </div>
    </article>
  );
}
