import { useState, type ReactNode } from 'react';
import { I18nProvider } from '../../shared/i18n/I18nProvider.js';
import { patientMessages } from '../i18n/messages.js';
import { CenterDefaultSetter, CenterProvider } from './center.js';
import { SessionProvider, useSession } from './session.js';

export const LOCALE_STORAGE_KEY = 'dc.patient.locale';

function WithLocale({ children }: { children: ReactNode }) {
  const { user } = useSession();
  const [centerDefault, setCenterDefault] = useState<string | null>(null);
  return (
    <CenterDefaultSetter.Provider value={setCenterDefault}>
      <I18nProvider messages={patientMessages} storageKey={LOCALE_STORAGE_KEY} accountLocale={user?.preferredLocale ?? null} centerDefault={centerDefault}>
        <CenterProvider>{children}</CenterProvider>
      </I18nProvider>
    </CenterDefaultSetter.Provider>
  );
}

/** Session -> language -> center profile. The router is supplied by the caller (BrowserRouter in the app, MemoryRouter in tests). */
export function PatientProviders({ children }: { children: ReactNode }) {
  return (
    <SessionProvider>
      <WithLocale>{children}</WithLocale>
    </SessionProvider>
  );
}
