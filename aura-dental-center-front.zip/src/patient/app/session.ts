import { createSession } from '../../shared/auth/createSession.js';
import type { PatientProfile } from '../../shared/api/types.js';
import { http, patientCalls } from '../api.js';

export interface LoginInput { phone: string; password: string }

export const { SessionProvider, useSession } = createSession<PatientProfile, LoginInput>({
  http,
  restore: async (signal) => {
    const r = await patientCalls.me(signal);
    return { user: r.patient, csrfToken: r.csrfToken };
  },
  login: async (input) => {
    const r = await patientCalls.login(input);
    return { user: r.patient, csrfToken: r.csrfToken };
  },
  logout: () => patientCalls.logout(),
});
