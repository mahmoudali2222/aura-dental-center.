import { createContext, useContext, useEffect, type ReactNode } from 'react';
import type { CenterInfo } from '../../shared/api/types.js';
import { useAsync } from '../../shared/lib/useAsync.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { pub } from '../api.js';

interface CenterValue {
  center: CenterInfo | null;
  loading: boolean;
  failed: boolean;
  reload: () => void;
}

const Ctx = createContext<CenterValue>({ center: null, loading: true, failed: false, reload: () => undefined });
const HintCtx = createContext<(l: string) => void>(() => undefined);

export const useCenter = () => useContext(Ctx);
export const CenterDefaultSetter = HintCtx;

/**
 * Loads the center profile (name, address, hours, slots) in the visitor's language. The address and contact details are
 * never written in the frontend: they come from here, i.e. from the admin dashboard's settings.
 */
export function CenterProvider({ children }: { children: ReactNode }) {
  const { locale } = useI18n();
  const reportDefault = useContext(HintCtx);
  const state = useAsync((signal) => pub.center(locale, signal), [locale]);
  useEffect(() => {
    if (state.data) reportDefault(state.data.defaultLocale);
  }, [state.data, reportDefault]);
  return <Ctx.Provider value={{ center: state.data ?? null, loading: state.status === 'loading' && !state.data, failed: state.status === 'error' && !state.data, reload: state.reload }}>{children}</Ctx.Provider>;
}
