/**
 * The students of Section 10 who built this project, written exactly as the group supplied them (spelling included).
 * Two students share the name "منه الله": both stay, as two separate entries.
 */
export const SECTION_10_STUDENTS: readonly string[] = [
  'ماريا ابراهيم', 'رضا حمدي', 'فاطمه محمد', 'سوسنه شحاته', 'سالمه سعد', 'نسمه محمد', 'محسن سامي', 'وديع عمر', 'يوسف محمد', 'محمد ياسر',
  'عزام علي', 'زايد مهدي', 'عمر بشير', 'مشعل رياض', 'راغب ممدوح', 'سارة محمد', 'زين علي', 'شهد عبدالله', 'مارتينا جوده', 'شهد عاطف',
  'هادى احمد', 'نوران احمد', 'اسراء محمد', 'محمود على', 'مايان اشرف', 'وعد عبدالمحسن', 'منه الله', 'منه الله', 'مريم عبدالباقى', 'احمد ابراهيم',
];

/** Soft background tones the chips cycle through (see styles/shell.css). Consecutive chips never share a tone. */
export const CHIP_TONES = ['sky', 'mint', 'peach', 'lilac'] as const;
export type ChipTone = (typeof CHIP_TONES)[number];
