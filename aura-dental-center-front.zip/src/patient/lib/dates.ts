import type { Locale } from '../../shared/api/types.js';
import { LOCALE_META } from '../../shared/i18n/types.js';

/** First day of the week in the calendar and the weekday strip (ISO: 1 = Monday ... 7 = Sunday). Arabic weeks start on Saturday. */
export const WEEK_START: Record<Locale, number> = { ar: 6, en: 1, fr: 1 };

/** The seven ISO weekdays in the order the language's calendar shows them. */
export function weekOrder(locale: Locale): number[] {
  const start = WEEK_START[locale];
  return Array.from({ length: 7 }, (_, i) => ((start - 1 + i) % 7) + 1);
}

/** ISO weekday (1 = Monday ... 7 = Sunday) of a plain calendar date "YYYY-MM-DD". */
export function isoWeekday(date: string): number {
  const d = new Date(`${date}T00:00:00Z`);
  return ((d.getUTCDay() + 6) % 7) + 1;
}

/** Single-letter weekday ("M", "ن") for compact displays. Always accompanied by the full text for screen readers. */
export function narrowWeekday(isoWeekdayNumber: number, locale: Locale): string {
  return new Intl.DateTimeFormat(LOCALE_META[locale].tag, { weekday: 'narrow', timeZone: 'UTC' }).format(new Date(Date.UTC(2026, 10, 1 + isoWeekdayNumber)));
}

/** "4 PM", "4 م", "16 h": the hour on its own, for tick labels. */
export function hourLabel(hhmm: string, locale: Locale): string {
  const m = /^(\d{1,2}):(\d{2})$/.exec(hhmm);
  if (!m) return hhmm;
  const d = new Date(Date.UTC(2000, 0, 1, Number(m[1]), Number(m[2])));
  const meta = LOCALE_META[locale];
  const options: Intl.DateTimeFormatOptions = meta.hour12 ? { hour: 'numeric', hour12: true, timeZone: 'UTC' } : { hour: 'numeric', hourCycle: 'h23', timeZone: 'UTC' };
  return new Intl.DateTimeFormat(meta.tag, options).format(d);
}

/** Today's calendar date in the center's time zone, "YYYY-MM-DD". */
export function todayIn(zone: string, now: Date = new Date()): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: zone, year: 'numeric', month: '2-digit', day: '2-digit' }).format(now);
}

export function addDaysTo(date: string, days: number): string {
  const d = new Date(`${date}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

/** "2026-11" of a date. */
export const monthKey = (date: string): string => date.slice(0, 7);

/** "November 2026", "نوفمبر 2026". */
export function monthTitle(key: string, locale: Locale): string {
  return new Intl.DateTimeFormat(LOCALE_META[locale].tag, { month: 'long', year: 'numeric', timeZone: 'UTC' }).format(new Date(`${key}-01T00:00:00Z`));
}

/**
 * The weeks of a month as rows of 7 cells; a cell is the date "YYYY-MM-DD" or null outside the month.
 * The first column is the language's first weekday.
 */
export function monthGrid(key: string, locale: Locale): (string | null)[][] {
  const first = `${key}-01`;
  const lead = (isoWeekday(first) - WEEK_START[locale] + 7) % 7;
  const probe = new Date(`${first}T00:00:00Z`);
  const daysInMonth = new Date(Date.UTC(probe.getUTCFullYear(), probe.getUTCMonth() + 1, 0)).getUTCDate();
  const cells: (string | null)[] = [...Array<null>(lead).fill(null), ...Array.from({ length: daysInMonth }, (_, i) => `${key}-${String(i + 1).padStart(2, '0')}`)];
  while (cells.length % 7 !== 0) cells.push(null);
  const rows: (string | null)[][] = [];
  for (let i = 0; i < cells.length; i += 7) rows.push(cells.slice(i, i + 7));
  return rows;
}

/** The pieces of the little "date leaf" on an appointment card: short month, day number and short weekday. */
export function dayLeaf(date: string, locale: Locale): { month: string; day: string; weekday: string } {
  const d = new Date(`${date}T00:00:00Z`);
  const tag = LOCALE_META[locale].tag;
  const part = (options: Intl.DateTimeFormatOptions) => new Intl.DateTimeFormat(tag, { ...options, timeZone: 'UTC' }).format(d);
  return { month: part({ month: 'short' }), day: part({ day: 'numeric' }), weekday: part({ weekday: 'short' }) };
}
