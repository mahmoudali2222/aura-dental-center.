import { Navigate, Route, Routes } from 'react-router-dom';
import { Layout } from './components/Layout.js';
import { RequireAuth } from './components/RequireAuth.js';
import { Home } from './pages/Home.js';
import { Departments } from './pages/Departments.js';
import { DepartmentPage } from './pages/DepartmentPage.js';
import { Login, Register } from './pages/AuthForms.js';
import { Account } from './pages/Account.js';
import { Book } from './pages/Book.js';
import { Appointments } from './pages/Appointments.js';

export function PatientRoutes() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="departments" element={<Departments />} />
        <Route path="departments/:slug" element={<DepartmentPage />} />
        <Route path="login" element={<Login />} />
        <Route path="register" element={<Register />} />
        <Route path="book" element={<RequireAuth><Book /></RequireAuth>} />
        <Route path="appointments" element={<RequireAuth><Appointments /></RequireAuth>} />
        <Route path="account" element={<RequireAuth><Account /></RequireAuth>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
