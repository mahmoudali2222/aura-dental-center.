import { useMemo, useState } from 'react';
import type { AvailabilityDay } from '../../shared/api/types.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { monthGrid, monthKey, monthTitle, weekOrder } from '../lib/dates.js';
import { useT } from '../i18n/useT.js';
import { ChevronEnd, ChevronStart } from './icons.js';

/** The most dots a day shows; the real number of free times is always in the accessible name. */
const MAX_DOTS = 6;

/**
 * Month calendar over REAL availability. Every cell comes from the availability endpoint's list of days: only days the API calls
 * "open" can be chosen; full, closed (a weekday the department or center does not work, or a closure), past and out-of-period days
 * are shown but cannot be picked. Nothing about working days or capacity is decided here. A dot marks each free time of a day.
 */
export function Calendar({ days, today, selected, onSelect, name }: { days: AvailabilityDay[]; today: string; selected: string | null; onSelect: (date: string) => void; name: string }) {
  const t = useT();
  const i18n = useI18n();
  const byDate = useMemo(() => new Map(days.map((d) => [d.date, d])), [days]);
  const months = useMemo(() => {
    const keys: string[] = [];
    for (const d of days) { const k = monthKey(d.date); if (keys[keys.length - 1] !== k) keys.push(k); }
    return keys;
  }, [days]);

  // open on the month the patient is looking at: their choice, else the first month that has anything to book
  const [shown, setShown] = useState(() => {
    const first = selected ?? days.find((d) => d.status === 'open')?.date ?? days[0]?.date;
    return first ? monthKey(first) : '';
  });
  const index = Math.max(0, months.indexOf(shown));
  const key = months[index] ?? shown;
  if (!key) return null;
  const grid = monthGrid(key, i18n.locale);
  const order = weekOrder(i18n.locale);

  return (
    <div className="cal">
      <div className="cal__head">
        <button type="button" className="icon-btn" onClick={() => setShown(months[index - 1] ?? key)} disabled={index <= 0} aria-label={t('book.month.prev')}><ChevronStart /></button>
        <h3 className="cal__title" aria-live="polite">{monthTitle(key, i18n.locale)}</h3>
        <button type="button" className="icon-btn" onClick={() => setShown(months[index + 1] ?? key)} disabled={index >= months.length - 1} aria-label={t('book.month.next')}><ChevronEnd /></button>
      </div>
      <div className="cal__week" aria-hidden="true">
        {order.map((d) => <span key={d}>{i18n.weekday(d, 'short')}</span>)}
      </div>
      <div className="cal__grid" role="radiogroup" aria-label={t('book.date')}>
        {grid.flat().map((date, i) => {
          if (!date) return <span key={`gap-${i}`} className="cal__cell cal__cell--gap" aria-hidden="true" />;
          const info = byDate.get(date);
          const dayNumber = String(Number(date.slice(8)));
          const classes = `cal__cell${date === today ? ' is-today' : ''}`;
          if (info?.status !== 'open') {
            return <span key={date} className={`${classes} is-off`} data-status={info?.status ?? 'outside'} aria-hidden="true"><span className="cal__num">{dayNumber}</span></span>;
          }
          return (
            <label key={date} className={`${classes} is-open${selected === date ? ' is-selected' : ''}`}>
              <input type="radio" name={name} value={date} className="visually-hidden" checked={selected === date} onChange={() => onSelect(date)} />
              <span className="visually-hidden">{`${i18n.date(date, 'long')}, ${i18n.tn('book.freeCount', info.availableCount)}`}</span>
              <span className="cal__num" aria-hidden="true">{dayNumber}</span>
              <span className="cal__dots" aria-hidden="true">{Array.from({ length: Math.min(info.availableCount, MAX_DOTS) }, (_, n) => <i key={n} />)}</span>
            </label>
          );
        })}
      </div>
    </div>
  );
}
