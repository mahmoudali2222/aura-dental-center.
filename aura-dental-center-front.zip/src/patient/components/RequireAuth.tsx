import { Navigate, useLocation } from 'react-router-dom';
import type { ReactNode } from 'react';
import { Loading } from '../../shared/ui/index.js';
import { useSession } from '../app/session.js';

/** Protected pages: wait for the session check, then either render or send the visitor to sign in and back again. */
export function RequireAuth({ children }: { children: ReactNode }) {
  const { status } = useSession();
  const location = useLocation();
  if (status === 'loading') return <div className="page container"><Loading /></div>;
  if (status === 'anonymous') return <Navigate to="/login" replace state={{ from: `${location.pathname}${location.search}`, needsLogin: true }} />;
  return <>{children}</>;
}
