import { Link } from 'react-router-dom';
import { patientConfig } from '../config.js';
import { useCenter } from '../app/center.js';
import { useT } from '../i18n/useT.js';

/**
 * The center's identity in the header and footer.
 *
 * LOGO SLOT: the official logo has not been supplied. Until it is, only the center's name is shown, as ordinary text (no drawn
 * symbol, no stand-in picture). The reserved space is the `.brand__logo` box: when `patientConfig.logo` is set, the picture appears
 * there and the layout does not move. If the picture already contains the name, the text stays for screen readers only.
 */
export function BrandMark({ linkTo = '/', className = '' }: { linkTo?: string | null; className?: string }) {
  const t = useT();
  const { center } = useCenter();
  const logo = patientConfig.logo;
  const name = center?.name || t('nav.home');
  const inner = (
    <>
      {logo ? <img className="brand__logo" src={logo.src} alt="" /> : null}
      <span className={logo?.includesName ? 'visually-hidden' : 'brand__name'}>{name}</span>
    </>
  );
  return linkTo ? <Link to={linkTo} className={`brand ${className}`.trim()}>{inner}</Link> : <span className={`brand ${className}`.trim()}>{inner}</span>;
}
