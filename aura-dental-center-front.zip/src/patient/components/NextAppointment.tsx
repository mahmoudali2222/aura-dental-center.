import { Link } from 'react-router-dom';
import { useAsync } from '../../shared/lib/useAsync.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { patientCalls } from '../api.js';
import { dayLeaf } from '../lib/dates.js';
import { useT } from '../i18n/useT.js';
import { ArrowEnd } from './icons.js';

/**
 * For a signed-in patient: their next booked visit, read from their real appointments. Shows nothing when there is none
 * (or while loading, or if the request fails): the home page never has to apologise for an optional strip.
 */
export function NextAppointment() {
  const t = useT();
  const i18n = useI18n();
  const upcoming = useAsync((signal) => patientCalls.appointments('upcoming', i18n.locale, 1, 1, signal), [i18n.locale]);
  const next = upcoming.data?.data.find((a) => a.status === 'booked');
  if (!next) return null;
  const leaf = dayLeaf(next.date, i18n.locale);
  return (
    <section className="container next" aria-labelledby="next-title">
      <div className="leaf" aria-hidden="true"><span className="leaf__month">{leaf.month}</span><span className="leaf__day tabular">{leaf.day}</span></div>
      <div className="next__text">
        <h2 id="next-title" className="next__title">{t('home.next.title')}</h2>
        <p className="next__when"><strong>{next.department.name}</strong> · {i18n.date(next.date)} · {i18n.range(next.startTime, next.endTime)}</p>
      </div>
      <Link to="/appointments" className="btn btn--secondary btn--small">{t('home.next.manage')}<ArrowEnd size={16} /></Link>
    </section>
  );
}
