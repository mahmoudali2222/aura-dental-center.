import { CHIP_TONES, SECTION_10_STUDENTS } from '../contributors.js';
import { useT } from '../i18n/useT.js';

/**
 * Acknowledgment of the Section 10 students who built the project. The names are not a numbered list: they are compact chips that
 * sit side by side and wrap, each as wide as its own name. The names are Arabic whatever language the page is in, so every chip
 * carries lang="ar" and dir="rtl". Chips cycle through four soft tones; the two students named "منه الله" therefore get different tones.
 * (The markup is a list for screen readers, but it is not drawn as one: no bullets, no numbers.)
 */
export function Contributors() {
  const t = useT();
  return (
    <section className="credits" aria-labelledby="credits-title">
      <div className="container">
        <h2 id="credits-title" className="credits__title">{t('credits.title')}</h2>
        <p className="credits__lead">{t('credits.lead')}</p>
        <ul className="chips">
          {SECTION_10_STUDENTS.map((name, i) => (
            <li key={`${name}-${i}`} className="chip" lang="ar" dir="rtl" data-tone={CHIP_TONES[i % CHIP_TONES.length]}>{name}</li>
          ))}
        </ul>
      </div>
    </section>
  );
}
