import { Link } from 'react-router-dom';
import type { CenterInfo, DepartmentSummary } from '../../shared/api/types.js';
import { useT } from '../i18n/useT.js';
import { WorkingDays } from './WorkingDays.js';
import { ArrowEnd } from './icons.js';

/**
 * One department in the index. The whole row opens the department page (the name link is stretched over it); "Book" is a
 * separate button on top. `detailed` adds the dentist, as the Departments page does.
 */
export function DepartmentRow({ department: d, center, detailed = false }: { department: DepartmentSummary; center: CenterInfo | null; detailed?: boolean }) {
  const t = useT();
  // on the Departments page the rows sit directly under the page title (level 2); on the home page they sit under a section title (level 3)
  const Heading = detailed ? 'h2' : 'h3';
  return (
    <li className="dept-row">
      <div className="dept-row__main">
        <Heading className="dept-row__name">
          <Link to={`/departments/${d.slug}`} className="dept-row__link">{d.name}</Link>
          <ArrowEnd size={18} />
        </Heading>
        <p className="dept-row__desc">{d.description}</p>
        {detailed && d.dentist ? <p className="dept-row__dentist">{t('departments.dentist')}: {d.dentist.name}{d.dentist.isSample ? ` (${t('common.sample')})` : ''}</p> : null}
      </div>
      <WorkingDays days={d.workingDays} centerDays={center?.workingDays} />
      <div className="dept-row__action">
        {d.bookable
          ? <Link to={`/book?department=${encodeURIComponent(d.slug)}`} className="btn btn--secondary btn--small" aria-label={t('departments.bookAria', { department: d.name })}>{t('departments.bookShort')}</Link>
          : <span className="muted">{t('departments.notBookable')}</span>}
      </div>
    </li>
  );
}
