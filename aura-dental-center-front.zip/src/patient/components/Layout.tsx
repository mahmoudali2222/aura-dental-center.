import { useEffect, useRef, useState } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { isolateLtr } from '../../shared/i18n/format.js';
import { LOCALE_META } from '../../shared/i18n/types.js';
import { LOCALES, type CenterInfo, type Locale } from '../../shared/api/types.js';
import { useCenter } from '../app/center.js';
import { useSession } from '../app/session.js';
import { patientCalls } from '../api.js';
import { patientConfig } from '../config.js';
import { useT } from '../i18n/useT.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { BrandMark } from './BrandMark.js';
import { Contributors } from './Contributors.js';
import { CloseIcon, MenuIcon, PhoneIcon, PinIcon, SendIcon } from './icons.js';

/** Header + footer around every page. */
export function Layout() {
  const t = useT();
  const { center } = useCenter();
  const { status, user, logout } = useSession();
  const { pathname } = useLocation();
  const main = useRef<HTMLElement>(null);
  const [menuOpen, setMenuOpen] = useState(false);

  // after navigating, move keyboard/screen-reader focus to the new page content and fold the mobile menu away
  useEffect(() => { main.current?.focus({ preventScroll: false }); setMenuOpen(false); }, [pathname]);
  useEffect(() => { if (center?.name) document.title = center.name; }, [center?.name]);

  return (
    <>
      <a className="skip-link" href="#main">{t('common.skipToContent')}</a>
      <header className="site-header">
        <div className="container site-header__bar">
          <BrandMark />
          <PatientLanguageSwitcher />
          <button type="button" className="menu-toggle" aria-expanded={menuOpen} aria-controls="site-menu" onClick={() => setMenuOpen((o) => !o)}>
            {menuOpen ? <CloseIcon /> : <MenuIcon />}
            <span className="visually-hidden">{t('nav.menu')}</span>
          </button>
          <div id="site-menu" className="site-menu" data-open={menuOpen}>
            <nav aria-label={t('nav.main')} className="site-nav">
              <NavLink to="/departments">{t('nav.departments')}</NavLink>
              {status === 'authenticated' ? (
                <>
                  <NavLink to="/appointments">{t('nav.appointments')}</NavLink>
                  <NavLink to="/account">{user?.fullName || t('nav.account')}</NavLink>
                </>
              ) : null}
            </nav>
            <div className="site-actions">
              {status === 'authenticated' ? (
                <button type="button" className="btn btn--ghost btn--small" onClick={() => void logout()}>{t('nav.logout')}</button>
              ) : status === 'anonymous' ? (
                <>
                  <NavLink to="/login" className="site-actions__link">{t('nav.login')}</NavLink>
                  <NavLink to="/register" className="site-actions__link">{t('nav.register')}</NavLink>
                </>
              ) : null}
              <Link to="/book" className="btn btn--small">{t('nav.book')}</Link>
            </div>
          </div>
        </div>
      </header>
      <main id="main" ref={main} tabIndex={-1} className="site-main">
        <Outlet />
      </main>
      <Footer center={center} />
    </>
  );
}

/**
 * Three language buttons, each named in its own language. Changing the language also saves it on the account when signed in
 * (and always in this browser).
 */
function PatientLanguageSwitcher() {
  const { locale, setLocale, t } = useI18n();
  const { status, user, update } = useSession();
  const last = useRef<Locale>(locale);
  useEffect(() => {
    if (status !== 'authenticated' || !user || last.current === locale) { last.current = locale; return; }
    last.current = locale;
    if (user.preferredLocale === locale) return;
    patientCalls.updateProfile({ preferredLocale: locale }).then((r) => update(r.patient), () => undefined);
  }, [locale, status, user, update]);
  const short: Record<Locale, string> = { ar: 'ع', en: 'EN', fr: 'FR' };
  return (
    <div className="lang-toggle" role="group" aria-label={t('lang.label')}>
      {LOCALES.map((l) => (
        <button key={l} type="button" lang={l} aria-label={LOCALE_META[l].nativeName} aria-pressed={locale === l} className="lang-toggle__btn" onClick={() => setLocale(l)}>
          {short[l]}
        </button>
      ))}
    </div>
  );
}

export function hoursSummary(center: CenterInfo, i18n: ReturnType<typeof useI18n>, t: ReturnType<typeof useT>): string {
  const first = center.slots[0];
  const last = center.slots[center.slots.length - 1];
  if (!first || !last) return '';
  const days = center.workingDays.length === 7 ? t('footer.everyDay') : i18n.list(center.workingDays.map((d) => i18n.weekday(d, 'short')));
  return t('footer.hoursText', { days, from: i18n.clock(first.startTime), to: i18n.clock(last.endTime), zone: center.timezone });
}

function Footer({ center }: { center: CenterInfo | null }) {
  const t = useT();
  const i18n = useI18n();
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div className="footer-about">
          <BrandMark linkTo={null} className="brand--footer" />
          {center?.introduction ? <p className="footer-about__text">{center.introduction}</p> : null}
          <a className="footer-telegram" href={patientConfig.telegram.botUrl} target="_blank" rel="noopener noreferrer">
            <SendIcon size={18} /> {t('telegram.card.open')}
          </a>
        </div>
        <section className="footer-contact" aria-labelledby="footer-contact-h">
          <h2 id="footer-contact-h">{t('footer.contact')}</h2>
          {center ? (
            <dl className="contact-list">
              <div>
                <dt><PinIcon size={18} /><span>{t('footer.address')}</span></dt>
                <dd>
                  {center.addressConfigured && center.address ? center.address : <span className="muted">{t('footer.addressMissing')}</span>}
                  {center.mapUrl ? <> <a href={center.mapUrl} target="_blank" rel="noopener noreferrer">{t('footer.map')}</a></> : null}
                </dd>
              </div>
              {center.phone ? <div><dt><PhoneIcon size={18} /><span>{t('footer.phone')}</span></dt><dd><a href={`tel:${center.phone}`} className="ltr">{isolateLtr(center.phone)}</a></dd></div> : null}
              {center.whatsapp ? <div><dt><PhoneIcon size={18} /><span>{t('footer.whatsapp')}</span></dt><dd><span className="ltr">{isolateLtr(center.whatsapp)}</span></dd></div> : null}
              {center.email ? <div><dt><span>{t('footer.email')}</span></dt><dd><a href={`mailto:${center.email}`}>{center.email}</a></dd></div> : null}
              <div>
                <dt><span>{t('footer.hours')}</span></dt>
                <dd>{hoursSummary(center, i18n, t)}</dd>
              </div>
            </dl>
          ) : null}
        </section>
      </div>
      <Contributors />
    </footer>
  );
}
