import { useEffect, useState } from 'react';
import type { HeroVideoConfig } from '../config.js';

/** True when the visitor asked their device for less motion. */
export function usePrefersReducedMotion(): boolean {
  const query = '(prefers-reduced-motion: reduce)';
  const [reduced, setReduced] = useState(() => (typeof window !== 'undefined' && typeof window.matchMedia === 'function' ? window.matchMedia(query).matches : false));
  useEffect(() => {
    if (typeof window.matchMedia !== 'function') return;
    const mq = window.matchMedia(query);
    const onChange = () => setReduced(mq.matches);
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);
  return reduced;
}

/**
 * The media layer behind the top of the home page.
 *
 * VIDEO SLOT: the real background video has not been supplied, so by default this renders only the empty layer (the hero's own
 * background shows through). It is already wired for the real file: pass a `video` (from `patientConfig.heroVideo`) and the video
 * plays muted and looped behind the hero text, under a light scrim that keeps the text readable. If the visitor prefers reduced
 * motion, it does not autoplay and shows its poster picture instead. The layer is decorative (hidden from screen readers) and
 * never receives focus.
 */
export function HeroMedia({ video }: { video: HeroVideoConfig | null }) {
  const reduced = usePrefersReducedMotion();
  return (
    <div className="hero__media" aria-hidden="true" data-media={video ? 'video' : 'none'}>
      {video ? <video className="hero__video" src={video.src} poster={video.poster} muted loop playsInline autoPlay={!reduced} preload="metadata" tabIndex={-1} /> : null}
      <div className="hero__scrim" />
    </div>
  );
}
