import { useEffect, useMemo, useState } from 'react';
import { Alert, Button, Loading } from '../../shared/ui/index.js';
import { useAsync } from '../../shared/lib/useAsync.js';
import { errorText } from '../../shared/lib/errors.js';
import { useI18n } from '../../shared/i18n/I18nProvider.js';
import { pub } from '../api.js';
import { useCenter } from '../app/center.js';
import { addDaysTo, todayIn } from '../lib/dates.js';
import { useT } from '../i18n/useT.js';
import { Calendar } from './Calendar.js';

export interface SlotChoice { date: string; slotNumber: number; startTime: string; endTime: string; endsNextDay: boolean }

/** Never ask for more than the API's own limit of days at once (see docs/API_REFERENCE.md). */
const MAX_SPAN = 62;

/**
 * Day + time chooser fed by the availability endpoint, which lists only genuinely bookable slots (the booking transaction
 * enforces the same rule again, so a stale choice is refused, never double-booked). It asks for every day of the center's booking
 * period (today to the booking horizon, both from the center's own settings) so the calendar can show the whole month.
 * `refreshKey` forces a reload.
 */
export function SlotPicker({ slug, value, onChange, refreshKey = 0 }: { slug: string; value: SlotChoice | null; onChange: (c: SlotChoice | null) => void; refreshKey?: number }) {
  const t = useT();
  const i18n = useI18n();
  const { center, loading: centerLoading } = useCenter();
  const zone = center?.timezone;
  const horizon = center?.bookingHorizonDays;
  const today = zone ? todayIn(zone) : '';
  const range = useMemo(() => (zone && horizon ? { from: today, to: addDaysTo(today, Math.min(horizon, MAX_SPAN) - 1) } : {}), [zone, horizon, today]);
  const state = useAsync((signal) => (centerLoading ? new Promise<never>(() => undefined) : pub.availability(slug, range, signal)), [slug, refreshKey, centerLoading, range.from, range.to]);
  const [day, setDay] = useState<string | null>(value?.date ?? null);

  const days = useMemo(() => (state.data?.days ?? []).filter((d) => d.status === 'open'), [state.data]);

  // keep the selection valid when availability changes under the user's feet
  useEffect(() => {
    if (!state.data) return;
    if (day && !days.some((d) => d.date === day)) { setDay(null); onChange(null); }
    else if (value && !days.some((d) => d.date === value.date && d.slots.some((s) => s.slotNumber === value.slotNumber))) onChange(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.data]);

  if ((state.status === 'loading' || centerLoading) && !state.data) return <Loading />;
  if (state.status === 'error' && !state.data) {
    return <Alert tone="error">{t('book.availabilityFailed')} {errorText(i18n, state.error)} <Button small variant="secondary" onClick={state.reload}>{t('common.retry')}</Button></Alert>;
  }
  if (days.length === 0) return <Alert tone="info">{t('book.noDays')}</Alert>;

  const selectedDay = days.find((d) => d.date === day);
  return (
    <div className="picker-wrap">
      <div className="picker">
        <div className="picker__calendar">
          <Calendar days={state.data?.days ?? []} today={state.data?.from ?? today} selected={day} name={`day-${slug}`} onSelect={(d) => { setDay(d); onChange(null); }} />
          <p className="picker__legend">{t('book.legend')}</p>
        </div>
        <div className="picker__times">
          {selectedDay ? (
            <fieldset className="times">
              <legend>{t('book.chooseTime')}</legend>
              <p className="times__day">{i18n.date(selectedDay.date, 'long')}</p>
              <div className="times__list" role="radiogroup" aria-label={t('book.time')}>
                {selectedDay.slots.map((s) => {
                  const checked = value?.date === selectedDay.date && value.slotNumber === s.slotNumber;
                  return (
                    <label key={s.slotNumber} className={`time${checked ? ' is-selected' : ''}`}>
                      <input type="radio" name={`slot-${slug}`} value={s.slotNumber} checked={checked} className="visually-hidden"
                        onChange={() => onChange({ date: selectedDay.date, slotNumber: s.slotNumber, startTime: s.startTime, endTime: s.endTime, endsNextDay: s.endsNextDay })} />
                      <span>{i18n.range(s.startTime, s.endTime)}</span>
                      {s.endsNextDay ? <span className="time__next"> ({t('common.nextDay')})</span> : null}
                    </label>
                  );
                })}
              </div>
            </fieldset>
          ) : <p className="picker__hint">{t('book.chooseDay')}</p>}
        </div>
      </div>
      <p className="picker__zone">{t('book.timezone', { zone: state.data?.timezone ?? '' })}</p>
    </div>
  );
}
