/**
 * The one place that talks to the backend. Everything else goes through the typed API modules built on this client.
 *
 * - Same-origin by design (the web container / dev proxy forwards /api), so session cookies are HttpOnly and never touched by JS.
 * - The CSRF token that login/me return is kept in memory and sent as X-CSRF-Token on every non-GET request.
 * - Every failure becomes an ApiError with the backend's stable `code`, which the UI translates; raw server text is never shown.
 */
export interface FieldIssue {
  field: string;
  code: string;
}

export interface PageMeta {
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
}

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    public readonly code: string,
    message?: string,
    public readonly details?: unknown,
  ) {
    super(message ?? code);
    this.name = 'ApiError';
  }

  /** Field-level validation issues ({ field, code }), when the backend sent any. */
  get fieldIssues(): FieldIssue[] {
    return Array.isArray(this.details)
      ? (this.details as unknown[]).filter((d): d is FieldIssue => typeof d === 'object' && d !== null && typeof (d as FieldIssue).field === 'string' && typeof (d as FieldIssue).code === 'string')
      : [];
  }

  /** True when the failure is "the server could not be reached or answered nonsense", as opposed to a deliberate refusal. */
  get isTransient(): boolean {
    return this.code === 'NETWORK_ERROR' || this.code === 'TIMEOUT' || this.code === 'UPSTREAM_ERROR' || this.status >= 500;
  }
}

export type Query = Record<string, string | number | boolean | null | undefined>;

export interface RequestOptions {
  query?: Query;
  body?: unknown;
  signal?: AbortSignal;
}

export interface HttpClient {
  get<T>(path: string, opts?: RequestOptions): Promise<T>;
  getPaged<T>(path: string, opts?: RequestOptions): Promise<{ data: T[]; meta: PageMeta }>;
  post<T = void>(path: string, body?: unknown, opts?: RequestOptions): Promise<T>;
  put<T = void>(path: string, body?: unknown, opts?: RequestOptions): Promise<T>;
  patch<T = void>(path: string, body?: unknown, opts?: RequestOptions): Promise<T>;
  del<T = void>(path: string, opts?: RequestOptions): Promise<T>;
  setCsrfToken(token: string | null): void;
  /** Called when an authenticated request is refused because the session is gone (expired, revoked, deactivated). */
  onSessionLost(handler: (() => void) | null): void;
}

export interface HttpClientOptions {
  baseUrl?: string;
  fetchImpl?: typeof fetch;
  timeoutMs?: number;
}

const SESSION_LOST_CODES = new Set(['SESSION_EXPIRED', 'UNAUTHENTICATED']);

export function buildUrl(baseUrl: string, path: string, query?: Query): string {
  const params = new URLSearchParams();
  for (const [k, v] of Object.entries(query ?? {})) {
    if (v === undefined || v === null || v === '') continue;
    params.set(k, String(v));
  }
  const qs = params.toString();
  return `${baseUrl}${path}${qs ? `?${qs}` : ''}`;
}

export function createHttpClient(options: HttpClientOptions = {}): HttpClient {
  const baseUrl = (options.baseUrl ?? '/api/v1').replace(/\/+$/, '');
  const timeoutMs = options.timeoutMs ?? 20_000;
  let csrf: string | null = null;
  let sessionLost: (() => void) | null = null;

  async function call(method: string, path: string, opts: RequestOptions = {}): Promise<{ data: unknown; meta?: PageMeta }> {
    const doFetch = options.fetchImpl ?? globalThis.fetch.bind(globalThis);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(new DOMException('timeout', 'TimeoutError')), timeoutMs);
    const onAbort = () => controller.abort(opts.signal?.reason);
    opts.signal?.addEventListener('abort', onAbort, { once: true });
    const headers: Record<string, string> = { accept: 'application/json' };
    const hasBody = opts.body !== undefined && method !== 'GET';
    if (hasBody) headers['content-type'] = 'application/json';
    if (method !== 'GET' && csrf) headers['x-csrf-token'] = csrf;

    let res: Response;
    try {
      res = await doFetch(buildUrl(baseUrl, path, opts.query), {
        method,
        headers,
        body: hasBody ? JSON.stringify(opts.body) : undefined,
        credentials: 'same-origin',
        signal: controller.signal,
      });
    } catch (err) {
      if (opts.signal?.aborted) throw err; // the caller cancelled on purpose (navigation, unmount): not an error to display
      const timedOut = err instanceof DOMException && err.name === 'TimeoutError';
      throw new ApiError(0, timedOut ? 'TIMEOUT' : 'NETWORK_ERROR', timedOut ? 'The server did not answer in time' : 'The server could not be reached');
    } finally {
      clearTimeout(timer);
      opts.signal?.removeEventListener('abort', onAbort);
    }

    const text = await res.text();
    let json: unknown = undefined;
    if (text) {
      try { json = JSON.parse(text); } catch { json = undefined; }
    }

    if (!res.ok) {
      const e = (json as { error?: { code?: unknown; message?: unknown; details?: unknown } } | undefined)?.error;
      const code = typeof e?.code === 'string' ? e.code : res.status >= 500 ? 'UPSTREAM_ERROR' : 'REQUEST_FAILED';
      const error = new ApiError(res.status, code, typeof e?.message === 'string' ? e.message : undefined, e?.details);
      if (res.status === 401 && SESSION_LOST_CODES.has(code)) sessionLost?.();
      throw error;
    }
    if (res.status === 204 || !text) return { data: undefined };
    if (typeof json !== 'object' || json === null || !('data' in json)) {
      throw new ApiError(res.status, 'UPSTREAM_ERROR', 'The server answered with an unexpected response');
    }
    const body = json as { data: unknown; meta?: PageMeta };
    return { data: body.data, meta: body.meta };
  }

  return {
    get: async <T>(path: string, opts?: RequestOptions) => (await call('GET', path, opts)).data as T,
    getPaged: async <T>(path: string, opts?: RequestOptions) => {
      const r = await call('GET', path, opts);
      return { data: r.data as T[], meta: r.meta ?? { page: 1, pageSize: (r.data as T[]).length, total: (r.data as T[]).length, totalPages: 1 } };
    },
    post: async <T = void>(path: string, body?: unknown, opts?: RequestOptions) => (await call('POST', path, { ...opts, body: body ?? {} })).data as T,
    put: async <T = void>(path: string, body?: unknown, opts?: RequestOptions) => (await call('PUT', path, { ...opts, body: body ?? {} })).data as T,
    patch: async <T = void>(path: string, body?: unknown, opts?: RequestOptions) => (await call('PATCH', path, { ...opts, body: body ?? {} })).data as T,
    del: async <T = void>(path: string, opts?: RequestOptions) => (await call('DELETE', path, opts)).data as T,
    setCsrfToken: (token) => { csrf = token; },
    onSessionLost: (handler) => { sessionLost = handler; },
  };
}
