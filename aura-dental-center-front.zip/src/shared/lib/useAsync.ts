import { useCallback, useEffect, useRef, useState } from 'react';
import { ApiError } from '../api/http.js';

export type AsyncState<T> =
  | { status: 'loading'; data: T | undefined; error: null }
  | { status: 'success'; data: T; error: null }
  | { status: 'error'; data: T | undefined; error: ApiError };

export function toApiError(err: unknown): ApiError {
  return err instanceof ApiError ? err : new ApiError(0, 'NETWORK_ERROR', err instanceof Error ? err.message : undefined);
}

/**
 * Runs `load` on mount and whenever `deps` change, ignoring answers that arrive after a newer request or an unmount.
 * Keeps the previous data visible while reloading so lists do not flash empty.
 */
export function useAsync<T>(load: (signal: AbortSignal) => Promise<T>, deps: readonly unknown[]): AsyncState<T> & { reload: () => void } {
  const [state, setState] = useState<AsyncState<T>>({ status: 'loading', data: undefined, error: null });
  const [tick, setTick] = useState(0);
  const loadRef = useRef(load);
  loadRef.current = load;

  useEffect(() => {
    const controller = new AbortController();
    setState((s) => ({ status: 'loading', data: s.data, error: null }));
    loadRef.current(controller.signal).then(
      (data) => { if (!controller.signal.aborted) setState({ status: 'success', data, error: null }); },
      (err: unknown) => { if (!controller.signal.aborted) setState((s) => ({ status: 'error', data: s.data, error: toApiError(err) })); },
    );
    return () => controller.abort();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick]);

  const reload = useCallback(() => setTick((t) => t + 1), []);
  return { ...state, reload } as AsyncState<T> & { reload: () => void };
}
