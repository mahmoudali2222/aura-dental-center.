import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import { PatientProviders, LOCALE_STORAGE_KEY } from '../src/patient/app/Providers.js';
import { PatientRoutes } from '../src/patient/App.js';
import { http } from '../src/patient/api.js';
import { patientConfig } from '../src/patient/config.js';
import { HeroMedia } from '../src/patient/components/HeroMedia.js';
import { patientMessages, type PatientKey } from '../src/patient/i18n/messages.js';
import { weekdayName } from '../src/shared/i18n/format.js';
import { appointmentFixture, availabilityFixture, centerFixture, deptDetail, deptSummary, ok, SLOTS, startFakeBackend } from './helpers/fakeBackend.js';

const msg = (l: 'en' | 'ar' | 'fr', key: PatientKey): string => (patientMessages[l] as Record<string, string>)[key]!;

function renderApp(path = '/', locale: 'en' | 'ar' | 'fr' = 'en') {
  localStorage.setItem(LOCALE_STORAGE_KEY, locale);
  return render(
    <MemoryRouter initialEntries={[path]}>
      <PatientProviders><PatientRoutes /></PatientProviders>
    </MemoryRouter>,
  );
}

const PICTURE = '/assets/departments/endodontics-before-after.jpg';
const withPictures = (api: ReturnType<typeof startFakeBackend>) => api.override((r) => (r.method === 'GET' && r.path === '/public/departments'
  ? ok([{ ...deptSummary, imagePath: PICTURE }, { ...deptSummary, id: '22222222-2222-4222-8222-222222222222', slug: 'orthodontics', name: 'Orthodontics', imagePath: null }])
  : undefined));

beforeEach(() => { http.setCsrfToken(null); });
afterEach(() => { vi.unstubAllGlobals(); vi.restoreAllMocks(); vi.useRealTimers(); patientConfig.logo = null; patientConfig.heroVideo = null; });

/** The names exactly as the center gave them for Section 10 (typed here again on purpose, so a change in the source is noticed). */
const SECTION_10 = ['ماريا ابراهيم', 'رضا حمدي', 'فاطمه محمد', 'سوسنه شحاته', 'سالمه سعد', 'نسمه محمد', 'محسن سامي', 'وديع عمر', 'يوسف محمد', 'محمد ياسر', 'عزام علي', 'زايد مهدي', 'عمر بشير', 'مشعل رياض', 'راغب ممدوح', 'سارة محمد', 'زين علي', 'شهد عبدالله', 'مارتينا جوده', 'شهد عاطف', 'هادى احمد', 'نوران احمد', 'اسراء محمد', 'محمود على', 'مايان اشرف', 'وعد عبدالمحسن', 'منه الله', 'منه الله', 'مريم عبدالباقى', 'احمد ابراهيم'];

describe('Section 10 contributors', () => {
  for (const locale of ['ar', 'en', 'fr'] as const) {
    it(`shows the 30 names exactly as given, in order, as compact chips and not as a numbered list (${locale})`, async () => {
      startFakeBackend();
      renderApp('/', locale);
      const section = await screen.findByRole('region', { name: msg(locale, 'credits.title') });
      const chips = within(section).getAllByRole('listitem');
      expect(chips.map((c) => c.textContent)).toEqual(SECTION_10);
      expect(section.querySelector('ol')).toBeNull();
      for (const chip of chips) { expect(chip).toHaveAttribute('lang', 'ar'); expect(chip).toHaveAttribute('dir', 'rtl'); }
    });
  }

  it('keeps both "منه الله" as separate entries with different background tones', async () => {
    startFakeBackend();
    renderApp('/', 'ar');
    const section = await screen.findByRole('region', { name: msg('ar', 'credits.title') });
    const same = within(section).getAllByText('منه الله');
    expect(same).toHaveLength(2);
    expect(same[0]!.dataset.tone).toBeTruthy();
    expect(same[1]!.dataset.tone).toBeTruthy();
    expect(same[0]!.dataset.tone).not.toBe(same[1]!.dataset.tone);
  });

  it('is the last thing on every public page (bottom of the Patient Dashboard)', async () => {
    startFakeBackend();
    renderApp('/departments', 'en');
    const section = await screen.findByRole('region', { name: msg('en', 'credits.title') });
    expect(section.closest('footer')).not.toBeNull();
    expect(document.body.querySelector('footer')!.lastElementChild).toBe(section);
  });
});

describe('Telegram assistant', () => {
  it('is reached through the bot link only, from the home page (band and footer) and the account page, with no chat window on the site', async () => {
    startFakeBackend({ signedIn: true });
    const { unmount } = renderApp('/', 'en');
    const links = await screen.findAllByRole('link', { name: /Open in Telegram/ });
    expect(links.length).toBeGreaterThanOrEqual(2);
    for (const a of links) {
      expect(a).toHaveAttribute('href', 'https://t.me/drAliclinic2_bot');
      expect(a).toHaveAttribute('target', '_blank');
      expect(a.getAttribute('rel')).toMatch(/noopener/);
    }
    expect(screen.queryByRole('textbox')).not.toBeInTheDocument();
    unmount();
    renderApp('/account', 'en');
    const account = await screen.findByRole('link', { name: /Open in Telegram/ });
    expect(account).toHaveAttribute('href', 'https://t.me/drAliclinic2_bot');
  });
});

describe('the places kept for the logo and the background video', () => {
  it('shows no logo and no video by default: only the center name as text, and an empty media layer', async () => {
    startFakeBackend();
    const { container } = renderApp('/', 'en');
    await screen.findByRole('heading', { level: 1 });
    expect(container.querySelector('.brand__logo')).toBeNull();
    expect(container.querySelector('video')).toBeNull();
    expect(container.querySelector('.hero__media')).toHaveAttribute('data-media', 'none');
    expect(within(container.querySelector('header')!).getByRole('link', { name: 'Test Dental Center' })).toBeInTheDocument();
  });

  it('takes the official logo from the website config when it is supplied, without any other change', async () => {
    patientConfig.logo = { src: '/assets/branding/logo.svg', includesName: true };
    startFakeBackend();
    const { container } = renderApp('/', 'en');
    await screen.findByRole('heading', { level: 1 });
    const img = container.querySelector('header .brand__logo');
    expect(img).toHaveAttribute('src', '/assets/branding/logo.svg');
    expect(within(container.querySelector('header')!).getByRole('link', { name: 'Test Dental Center' })).toBeInTheDocument(); // the name stays for screen readers
  });

  it('plays a configured video muted and looped behind the hero, and shows only the poster to visitors who prefer less motion', () => {
    const { container, rerender } = render(<HeroMedia video={{ src: '/assets/branding/hero.mp4', poster: '/assets/branding/hero.jpg' }} />);
    const video = container.querySelector('video')!;
    expect(video).toHaveAttribute('src', '/assets/branding/hero.mp4');
    expect(video).toHaveAttribute('poster', '/assets/branding/hero.jpg');
    expect(video.muted).toBe(true);
    expect(video).toHaveAttribute('loop');
    expect(container.querySelector('.hero__media')).toHaveAttribute('aria-hidden', 'true');
    expect(container.querySelector('.hero__media')).toHaveAttribute('data-media', 'video');

    vi.stubGlobal('matchMedia', () => ({ matches: true, addEventListener: () => undefined, removeEventListener: () => undefined }));
    rerender(<HeroMedia video={null} />);
    expect(container.querySelector('video')).toBeNull();
    const reduced = render(<HeroMedia video={{ src: '/assets/branding/hero.mp4' }} />);
    expect(reduced.container.querySelector('video')!.autoplay).toBe(false);
  });
});

describe('home page content comes from the API', () => {
  it('draws the evening from the center’s real slots and working days', async () => {
    startFakeBackend({ center: centerFixture({ slots: SLOTS.slice(0, 2), workingDays: [1, 3, 5] }) });
    renderApp('/', 'en');
    const timeline = await screen.findByRole('complementary', { name: msg('en', 'home.timeline.title') });
    expect(within(timeline).getAllByRole('listitem')).toHaveLength(2);
    expect(timeline.textContent).toMatch(/Monday, Wednesday,? (and |& )?Friday/);
    expect(timeline.textContent).toMatch(/4:00\s?pm\s?[–-]\s?8:00\s?pm/i);
  });

  it('shows the before/after pictures of the departments that have one, exactly at the path the API gives, and leaves out the rest', async () => {
    const api = startFakeBackend();
    withPictures(api);
    const { container } = renderApp('/', 'en');
    await screen.findByRole('heading', { name: msg('en', 'home.results.title') });
    const imgs = [...container.querySelectorAll<HTMLImageElement>('.results__img')];
    expect(imgs).toHaveLength(1);
    expect(imgs[0]!.getAttribute('src')).toBe(PICTURE);
    expect(imgs[0]).not.toHaveAttribute('width'); // never stretched or cropped by the page
  });

  it('drops a picture whose file is missing instead of showing a broken image, and hides the section when none is left', async () => {
    const api = startFakeBackend();
    withPictures(api);
    const { container } = renderApp('/', 'en');
    const img = await waitFor(() => { const i = container.querySelector('.results__img'); expect(i).not.toBeNull(); return i!; });
    fireEvent.error(img);
    await waitFor(() => expect(container.querySelector('.results__img')).toBeNull());
    expect(screen.queryByRole('heading', { name: msg('en', 'home.results.title') })).not.toBeInTheDocument();
  });

  it('shows no results section at all when no department has a picture', async () => {
    startFakeBackend();
    renderApp('/', 'en');
    await screen.findByRole('link', { name: 'Endodontics' });
    expect(screen.queryByRole('heading', { name: msg('en', 'home.results.title') })).not.toBeInTheDocument();
  });

  it('lists each department with its working days and a booking link that carries the department', async () => {
    const api = startFakeBackend();
    api.override((r) => (r.method === 'GET' && r.path === '/public/departments' ? ok([{ ...deptSummary, workingDays: [1, 3, 5] }]) : undefined));
    renderApp('/', 'en');
    const book = await screen.findByRole('link', { name: 'Book in Endodontics' });
    expect(book).toHaveAttribute('href', '/book?department=endodontics');
    expect(screen.getByRole('img', { name: /Working days: Monday, Wednesday,? (and |& )?Friday/ })).toBeInTheDocument();
  });

  it('shows a signed-in patient their next appointment, and nothing to a visitor', async () => {
    startFakeBackend({ signedIn: true, appointments: [appointmentFixture()] });
    const first = renderApp('/', 'en');
    const strip = await screen.findByRole('region', { name: msg('en', 'home.next.title') });
    expect(strip.textContent).toMatch(/Endodontics/);
    expect(within(strip).getByRole('link', { name: new RegExp(msg('en', 'home.next.manage')) })).toHaveAttribute('href', '/appointments');
    first.unmount();
    vi.unstubAllGlobals();
    startFakeBackend({ signedIn: false });
    renderApp('/', 'en');
    await screen.findByRole('heading', { level: 1 });
    expect(screen.queryByRole('region', { name: msg('en', 'home.next.title') })).not.toBeInTheDocument();
  });
});

describe('department page', () => {
  it('shows the supplied before/after picture uncropped with a description, from the API path', async () => {
    const api = startFakeBackend();
    api.override((r) => (r.method === 'GET' && r.path === '/public/departments/endodontics' ? ok({ ...deptDetail, imagePath: PICTURE }) : undefined));
    renderApp('/departments/endodontics', 'en');
    const img = await screen.findByRole('img', { name: 'Endodontics: before and after example' });
    expect(img).toHaveAttribute('src', PICTURE);
  });

  it('has no example section when the department has no picture', async () => {
    startFakeBackend();
    renderApp('/departments/endodontics', 'en');
    await screen.findByRole('heading', { level: 1, name: 'Endodontics' });
    expect(screen.queryByRole('heading', { name: msg('en', 'departments.example') })).not.toBeInTheDocument();
  });
});

describe('booking calendar (real availability only)', () => {
  it('asks for the center’s whole booking period, counted from today in the CENTER’s time zone', async () => {
    vi.useFakeTimers({ toFake: ['Date'] });
    vi.setSystemTime(new Date('2026-11-05T22:30:00Z')); // already the 6th in Cairo
    const api = startFakeBackend({ signedIn: true });
    renderApp('/book?department=endodontics', 'en');
    await screen.findByRole('radio', { name: /10 November 2026/ });
    const q = api.calls('GET', /availability$/)[0]!.query;
    expect(q.get('from')).toBe('2026-11-06');
    expect(q.get('to')).toBe('2027-01-04'); // 60 days: today + 59 (the center’s booking horizon)
  });

  it('shows what each day offers (free times as dots and in its name) and only lets the patient pick days that are open', async () => {
    const availability = availabilityFixture([1, 2]);
    availability.days = [
      { ...availability.days[0]!, date: '2026-11-30', status: 'full', availableCount: 0, slots: [] },
      { ...availability.days[0]!, date: '2026-12-01' },
      { ...availability.days[1]!, date: '2026-12-02', availableCount: 1, slots: availability.days[1]!.slots.slice(0, 1) },
    ];
    startFakeBackend({ signedIn: true, availability });
    const user = userEvent.setup();
    const { container } = renderApp('/book?department=endodontics', 'en');
    // opens on the first month with something to book
    expect(await screen.findByRole('heading', { name: 'December 2026' })).toBeInTheDocument();
    expect(screen.getByRole('radio', { name: /1 December 2026, 2 free times/ })).toBeInTheDocument();
    expect(screen.getByRole('radio', { name: /2 December 2026, 1 free time$/ })).toBeInTheDocument();
    expect(container.querySelectorAll('.cal__cell.is-open')).toHaveLength(2);
    expect(screen.getByRole('button', { name: msg('en', 'book.month.next') })).toBeDisabled();
    // the full day of the previous month is shown, but cannot be chosen
    await user.click(screen.getByRole('button', { name: msg('en', 'book.month.prev') }));
    expect(screen.getByRole('heading', { name: 'November 2026' })).toBeInTheDocument();
    expect(screen.queryByRole('radio', { name: /30 November/ })).not.toBeInTheDocument();
    expect(container.querySelector('.cal__cell[data-status="full"]')).not.toBeNull();
    expect(screen.getByRole('button', { name: msg('en', 'book.month.prev') })).toBeDisabled();
  });

  it('says so, and offers no day, when the API reports nothing bookable', async () => {
    const availability = availabilityFixture();
    availability.days = availability.days.map((d) => ({ ...d, status: 'full' as const, availableCount: 0, slots: [] }));
    startFakeBackend({ signedIn: true, availability });
    renderApp('/book?department=endodontics', 'en');
    expect(await screen.findByText(msg('en', 'book.noDays'))).toBeInTheDocument();
    expect(screen.queryByRole('radio', { name: /November 2026/ })).not.toBeInTheDocument();
  });

  it('starts the Arabic calendar week on Saturday and the English one on Monday', async () => {
    startFakeBackend({ signedIn: true });
    const ar = renderApp('/book?department=endodontics', 'ar');
    await waitFor(() => expect(ar.container.querySelector('.cal__week span')).not.toBeNull());
    expect(ar.container.querySelector('.cal__week span')!.textContent).toBe(weekdayName(6, 'ar', 'short'));
    ar.unmount();
    vi.unstubAllGlobals();
    startFakeBackend({ signedIn: true });
    const en = renderApp('/book?department=endodontics', 'en');
    await waitFor(() => expect(en.container.querySelector('.cal__week span')).not.toBeNull());
    expect(en.container.querySelector('.cal__week span')!.textContent).toBe(weekdayName(1, 'en', 'short'));
  });

  it('offers a service as an optional choice and sends it with the booking', async () => {
    const api = startFakeBackend({ signedIn: true });
    const user = userEvent.setup();
    renderApp('/book?department=endodontics', 'en');
    const services = await screen.findByRole('radiogroup', { name: msg('en', 'book.service') });
    expect(within(services).getByRole('radio', { name: msg('en', 'book.service.none') })).toBeChecked();
    await user.click(within(services).getByRole('radio', { name: 'Root canal' }));
    await user.click(await screen.findByRole('radio', { name: /10 November 2026/ }));
    await user.click(await screen.findByRole('radio', { name: /^6:00\s?pm/i }));
    await user.click(screen.getByRole('button', { name: msg('en', 'book.submit') }));
    await screen.findByText(msg('en', 'book.success'));
    expect(api.calls('POST', '/patient/appointments')[0]!.body.serviceId).toBe('s1');
  });

  it('choosing a department in the page puts it in the address, so the page can be shared and reloaded', async () => {
    startFakeBackend({ signedIn: true });
    const user = userEvent.setup();
    renderApp('/book', 'en');
    const group = await screen.findByRole('radiogroup', { name: msg('en', 'book.department') });
    expect(screen.queryByRole('radiogroup', { name: msg('en', 'book.time') })).not.toBeInTheDocument();
    await user.click(within(group).getByRole('radio', { name: 'Endodontics' }));
    expect(await screen.findByRole('radio', { name: /10 November 2026/ })).toBeInTheDocument();
  });
});

describe('patient precautions', () => {
  it('sits in the booking flow as the supplied picture with its text next to it, and the note field still says not to write medical details', async () => {
    startFakeBackend({ signedIn: true });
    const { container } = renderApp('/book?department=endodontics', 'en');
    await screen.findByRole('radio', { name: /10 November 2026/ });
    const img = container.querySelector('.precautions__img')!;
    expect(img).toHaveAttribute('src', '/assets/info/patient-precautions.jpg');
    expect(img.getAttribute('alt')).toContain(msg('en', 'precautions.sugar'));
    expect(screen.getByText(msg('en', 'book.note.hint'))).toBeInTheDocument();
  });

  it('is readable as text in French too (the picture itself is Arabic and English)', async () => {
    startFakeBackend({ signedIn: true });
    const user = userEvent.setup();
    renderApp('/book?department=endodontics', 'fr');
    await user.click(await screen.findByText(msg('fr', 'book.before.readText')));
    for (const k of ['precautions.sugar', 'precautions.heart', 'precautions.thinners', 'precautions.chronic'] as const) {
      expect(screen.getAllByText(msg('fr', k)).length).toBeGreaterThan(0);
    }
  });

  it('is shown again after booking, and from "My appointments" for a booked visit', async () => {
    startFakeBackend({ signedIn: true, appointments: [appointmentFixture()] });
    const user = userEvent.setup();
    const book = renderApp('/book?department=endodontics', 'en');
    await user.click(await screen.findByRole('radio', { name: /10 November 2026/ }));
    await user.click(await screen.findByRole('radio', { name: /^6:00\s?pm/i }));
    await user.click(screen.getByRole('button', { name: msg('en', 'book.submit') }));
    await screen.findByText(msg('en', 'book.success'));
    expect(book.container.querySelector('.precautions__img')).not.toBeNull();
    book.unmount();
    vi.unstubAllGlobals();

    startFakeBackend({ signedIn: true, appointments: [appointmentFixture()] });
    renderApp('/appointments', 'en');
    const card = await screen.findByRole('article', { name: /Endodontics/ });
    await user.click(within(card).getByRole('button', { name: msg('en', 'appts.before') }));
    const dialog = await screen.findByRole('dialog', { name: msg('en', 'appts.before') });
    expect(dialog.querySelector('.precautions__img')).toHaveAttribute('src', '/assets/info/patient-precautions.jpg');
  });
});

describe('rescheduling', () => {
  it('opens the same real calendar inside the appointment, shows the current time, and sends only the new day and slot', async () => {
    const api = startFakeBackend({ signedIn: true, appointments: [appointmentFixture()] });
    api.override((r) => (r.method === 'POST' && /\/reschedule$/.test(r.path) ? ok(appointmentFixture({ date: '2026-11-11', slotNumber: 1 })) : undefined));
    const user = userEvent.setup();
    renderApp('/appointments', 'en');
    const card = await screen.findByRole('article', { name: /Endodontics/ });
    await user.click(within(card).getByRole('button', { name: msg('en', 'appts.reschedule') }));
    expect(await within(card).findByText(/Currently:/)).toBeInTheDocument();
    await user.click(await within(card).findByRole('radio', { name: /11 November 2026/ }));
    await user.click(await within(card).findByRole('radio', { name: /^4:00\s?pm/i }));
    await user.click(within(card).getByRole('button', { name: msg('en', 'appts.reschedule.confirm') }));
    expect(await screen.findByText(msg('en', 'appts.rescheduled'))).toBeInTheDocument();
    const call = api.calls('POST', /reschedule$/)[0]!;
    expect(call.body).toEqual({ date: '2026-11-11', slotNumber: 1 });
    expect(call.headers['x-csrf-token']).toBe('csrf-1');
  });
});

describe('Arabic layout', () => {
  it('the home page is right-to-left with Arabic text everywhere on it (no English fallback strings)', async () => {
    startFakeBackend();
    const { container } = renderApp('/', 'ar');
    await screen.findByRole('heading', { level: 1, name: msg('ar', 'home.hero') });
    expect(document.documentElement.dir).toBe('rtl');
    expect(container.querySelector('.hero__lead')).not.toBeNull();
    expect(screen.getByRole('button', { name: 'العربية' })).toHaveAttribute('aria-pressed', 'true');
    expect(screen.getAllByRole('link', { name: msg('ar', 'telegram.card.open') }).length).toBeGreaterThan(0);
  });
});
