import { describe, expect, it } from 'vitest';
import { addDaysTo, dayLeaf, hourLabel, isoWeekday, monthGrid, monthKey, monthTitle, narrowWeekday, todayIn, weekOrder } from '../src/patient/lib/dates.js';

describe('calendar helpers of the patient site', () => {
  it('Arabic weeks start on Saturday, English and French on Monday', () => {
    expect(weekOrder('ar')).toEqual([6, 7, 1, 2, 3, 4, 5]);
    expect(weekOrder('en')).toEqual([1, 2, 3, 4, 5, 6, 7]);
    expect(weekOrder('fr')).toEqual([1, 2, 3, 4, 5, 6, 7]);
  });

  it('knows the ISO weekday of a plain date', () => {
    expect(isoWeekday('2026-11-01')).toBe(7); // Sunday
    expect(isoWeekday('2026-11-02')).toBe(1); // Monday
    expect(isoWeekday('2026-11-07')).toBe(6); // Saturday
  });

  it('lays a month out in rows of seven, starting at the language’s first weekday', () => {
    const en = monthGrid('2026-11', 'en'); // 1 Nov 2026 is a Sunday: six empty cells before it in a Monday-first week
    expect(en.every((row) => row.length === 7)).toBe(true);
    expect(en[0]!.slice(0, 6)).toEqual([null, null, null, null, null, null]);
    expect(en[0]![6]).toBe('2026-11-01');
    const ar = monthGrid('2026-11', 'ar'); // Saturday-first: Sunday is the second column
    expect(ar[0]![0]).toBeNull();
    expect(ar[0]![1]).toBe('2026-11-01');
    const days = (rows: (string | null)[][]) => rows.flat().filter(Boolean);
    expect(days(en)).toHaveLength(30);
    expect(days(ar)).toHaveLength(30);
    expect(days(en)[29]).toBe('2026-11-30');
  });

  it('handles leap-year February and month ends', () => {
    expect(monthGrid('2028-02', 'en').flat().filter(Boolean)).toHaveLength(29);
    expect(monthGrid('2027-02', 'en').flat().filter(Boolean)).toHaveLength(28);
    expect(addDaysTo('2026-12-31', 1)).toBe('2027-01-01');
    expect(addDaysTo('2026-11-05', 59)).toBe('2027-01-03');
    expect(monthKey('2026-11-30')).toBe('2026-11');
  });

  it('"today" is the date in the center’s time zone, not the visitor’s', () => {
    const instant = new Date('2026-11-05T22:30:00Z'); // already the 6th in Cairo (UTC+2), still the 5th in UTC
    expect(todayIn('Africa/Cairo', instant)).toBe('2026-11-06');
    expect(todayIn('UTC', instant)).toBe('2026-11-05');
  });

  it('names months, hours and date leaves in each language with Latin digits', () => {
    expect(monthTitle('2026-11', 'en')).toBe('November 2026');
    expect(monthTitle('2026-11', 'ar')).toMatch(/نوفمبر 2026/);
    expect(monthTitle('2026-11', 'fr')).toBe('novembre 2026');
    expect(hourLabel('16:00', 'en')).toMatch(/^4\s?pm$/i);
    expect(hourLabel('16:00', 'ar')).toMatch(/^4\s?م$/);
    expect(hourLabel('16:00', 'fr')).toMatch(/16/);
    expect(dayLeaf('2026-11-10', 'en')).toEqual({ month: 'Nov', day: '10', weekday: 'Tue' });
    expect(dayLeaf('2026-11-10', 'ar').day).toBe('10');
    expect(narrowWeekday(6, 'ar')).toHaveLength(1);
  });
});
