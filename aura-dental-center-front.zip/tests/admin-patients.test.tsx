import { afterEach, describe, expect, it, vi } from 'vitest';
import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { adminAppointmentFixture, fail, json, ok, startAdminBackend } from './helpers/adminBackend.js';
import { msg, renderAdmin } from './helpers/renderAdmin.js';
import type { AdminPatient, MedicalRecord } from '../src/admin/api/types.js';

afterEach(() => { vi.unstubAllGlobals(); vi.restoreAllMocks(); });

const lbl = (text: string) => new RegExp(text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
const meta = (total: number, page = 1, totalPages = 1) => ({ page, pageSize: 25, total, totalPages });
const patient = (over: Partial<AdminPatient> = {}): AdminPatient => ({
  id: 'p1', phone: '+201000000009', fullName: 'Layla Hassan', preferredLocale: 'ar', isActive: true, lastLoginAt: '2026-11-01T10:00:00+02:00', createdAt: '2026-10-01T10:00:00+02:00', telegramLinked: false, ...over,
});
const record = (over: Partial<MedicalRecord> = {}): MedicalRecord => ({
  id: 'm1', patientId: 'p1', appointmentId: null, medicalHistory: 'Hypertension', allergies: 'Penicillin', diagnosis: '', treatment: '', notes: '',
  createdBy: { id: 'adm-1', username: 'admin' }, updatedBy: { id: 'adm-1', username: 'admin' }, createdAt: '2026-11-01T10:00:00+02:00', updatedAt: '2026-11-01T10:00:00+02:00', ...over,
});

function setup(opts: { patients?: AdminPatient[]; records?: MedicalRecord[]; totalPages?: number } = {}) {
  const api = startAdminBackend();
  const patients = opts.patients ?? [patient()];
  const records = opts.records ?? [];
  api.route((r) => {
    if (r.method === 'GET' && r.path === '/admin/patients') return ok(patients, meta(patients.length, Number(r.query.get('page') ?? 1), opts.totalPages ?? 1));
    const one = /^\/admin\/patients\/([^/]+)$/.exec(r.path);
    if (one) {
      const p = patients.find((x) => x.id === one[1]);
      if (!p) return fail(404, 'PATIENT_NOT_FOUND');
      if (r.method === 'GET') return ok(p);
      if (r.method === 'PATCH') { Object.assign(p, r.body); return ok(p); }
    }
    if (r.method === 'GET' && r.path === '/admin/appointments') return ok([adminAppointmentFixture()], meta(1));
    if (r.method === 'GET' && /^\/admin\/patients\/[^/]+\/medical-records$/.test(r.path)) return ok(records);
    if (r.method === 'POST' && /^\/admin\/patients\/[^/]+\/medical-records$/.test(r.path)) { const rec = record({ id: 'm-new', ...r.body }); records.unshift(rec); return json(201, { data: rec }); }
    const mr = /^\/admin\/medical-records\/([^/]+)$/.exec(r.path);
    if (r.method === 'PATCH' && mr) { const rec = records.find((x) => x.id === mr[1])!; Object.assign(rec, r.body, { updatedAt: '2026-11-02T10:00:00+02:00' }); return ok(rec); }
    if (r.method === 'POST' && /\/reset-password$/.test(r.path)) return new Response(null, { status: 204 });
    if (r.method === 'POST' && /\/telegram\/revoke$/.test(r.path)) { patients[0]!.telegramLinked = false; return new Response(null, { status: 204 }); }
    return undefined;
  });
  return { api, patients, records };
}

describe('patient list', () => {
  it('lists patients, sends search and status filters, and pages', async () => {
    const { api } = setup({ totalPages: 2 });
    const user = userEvent.setup();
    renderAdmin('/patients');
    expect(await screen.findByRole('link', { name: 'Layla Hassan' })).toBeInTheDocument();
    expect(screen.getByText('1 result')).toBeInTheDocument();
    expect(api.calls('GET', '/admin/patients')[0]!.query.get('q')).toBeNull();

    await user.click(screen.getByRole('button', { name: msg('common.next') }));
    await waitFor(() => expect(api.calls('GET', '/admin/patients').at(-1)!.query.get('page')).toBe('2'));

    await user.type(screen.getByLabelText(msg('pat.search.label')), '  layla ');
    await user.selectOptions(screen.getByLabelText(msg('pat.filter.label')), 'false');
    await user.click(screen.getByRole('button', { name: msg('common.search') }));
    await waitFor(() => {
      const q = api.calls('GET', '/admin/patients').at(-1)!.query;
      expect(q.get('q')).toBe('layla');
      expect(q.get('active')).toBe('false');
      expect(q.get('page')).toBe('1');
    });
  });

  it('says so when nothing matches and offers a retry when the list cannot load', async () => {
    const { api } = setup({ patients: [] });
    renderAdmin('/patients');
    expect(await screen.findByText(msg('pat.empty'))).toBeInTheDocument();

    let down = true;
    api.route((r) => (down && r.path === '/admin/patients' ? fail(503, 'SERVICE_UNAVAILABLE') : undefined));
    const user = userEvent.setup();
    renderAdmin('/patients');
    const retry = await screen.findByRole('button', { name: msg('common.retry') });
    down = false;
    await user.click(retry);
    await waitFor(() => expect(screen.getAllByText(msg('pat.empty')).length).toBeGreaterThan(0));
  });
});

describe('create patient', () => {
  async function open(user: ReturnType<typeof userEvent.setup>) {
    await screen.findByText('Layla Hassan');
    await user.click(screen.getByRole('button', { name: msg('pat.add') }));
    return screen.findByRole('dialog', { name: msg('pat.create.title') });
  }
  async function fillIn(user: ReturnType<typeof userEvent.setup>, dialog: HTMLElement, phone = '01012345678') {
    await user.type(within(dialog).getByLabelText(lbl(msg('pat.field.fullName'))), 'Nour Adel');
    await user.type(within(dialog).getByLabelText(lbl(msg('pat.field.phone'))), phone);
    await user.type(within(dialog).getByLabelText(lbl(msg('pat.field.password'))), 'walk-in-pass-1');
  }

  it('creates the account and opens it; the password goes to the API only', async () => {
    const { api, patients } = setup();
    api.route((r) => {
      if (r.method === 'POST' && r.path === '/admin/patients') { const p = patient({ id: 'p-new', fullName: r.body.fullName, phone: '+201012345678' }); patients.push(p); return json(201, { data: p }); }
      return undefined;
    });
    const user = userEvent.setup();
    renderAdmin('/patients');
    const dialog = await open(user);
    await fillIn(user, dialog);
    await user.selectOptions(within(dialog).getByLabelText(lbl(msg('pat.field.language'))), 'fr');
    await user.click(within(dialog).getByRole('button', { name: msg('pat.create.submit') }));
    expect(await screen.findByRole('heading', { level: 1, name: 'Nour Adel' })).toBeInTheDocument();
    const call = api.calls('POST', '/admin/patients')[0]!;
    expect(call.body).toEqual({ fullName: 'Nour Adel', phone: '01012345678', password: 'walk-in-pass-1', preferredLocale: 'fr' });
    expect(call.headers['x-csrf-token']).toBe('csrf-admin');
  });

  it('an already registered phone number is shown at the phone field, once', async () => {
    const { api } = setup();
    api.route((r) => (r.method === 'POST' && r.path === '/admin/patients' ? fail(409, 'PHONE_ALREADY_REGISTERED') : undefined));
    const user = userEvent.setup();
    renderAdmin('/patients');
    const dialog = await open(user);
    await fillIn(user, dialog);
    await user.click(within(dialog).getByRole('button', { name: msg('pat.create.submit') }));
    const phone = within(dialog).getByLabelText(lbl(msg('pat.field.phone')));
    await waitFor(() => expect(phone).toHaveAttribute('aria-invalid', 'true'));
    expect(within(dialog).getAllByText(msg('err.PHONE_ALREADY_REGISTERED'))).toHaveLength(1);
    expect(screen.queryByText(/developer text/)).not.toBeInTheDocument();
  });

  it('a weak initial password is shown at the password field and nothing is created', async () => {
    const { api } = setup();
    api.route((r) => (r.method === 'POST' && r.path === '/admin/patients' ? fail(400, 'PASSWORD_TOO_SHORT') : undefined));
    const user = userEvent.setup();
    renderAdmin('/patients');
    const dialog = await open(user);
    await fillIn(user, dialog);
    await user.click(within(dialog).getByRole('button', { name: msg('pat.create.submit') }));
    await waitFor(() => expect(within(dialog).getByLabelText(lbl(msg('pat.field.password')))).toHaveAttribute('aria-invalid', 'true'));
    expect(within(dialog).getByText(msg('err.PASSWORD_TOO_SHORT'))).toBeInTheDocument();
  });
});

describe('patient page', () => {
  it('shows the profile, account state, appointments and loads the patient by id', async () => {
    setup({ patients: [patient({ telegramLinked: true })] });
    renderAdmin('/patients/p1');
    expect(await screen.findByRole('heading', { level: 1, name: 'Layla Hassan' })).toBeInTheDocument();
    expect(screen.getByLabelText(msg('pat.field.fullName'))).toHaveValue('Layla Hassan');
    expect(screen.getByText(msg('pat.telegram.linked'))).toBeInTheDocument();
    const appts = screen.getByRole('region', { name: msg('pat.appts.title') });
    expect(await within(appts).findByText('Endodontics')).toBeInTheDocument();
  });

  it('a patient that does not exist is reported, not shown blank', async () => {
    setup();
    renderAdmin('/patients/nope');
    expect(await screen.findByText(new RegExp(msg('pat.loadFailed')))).toBeInTheDocument();
    expect(screen.getByText(lbl(msg('err.PATIENT_NOT_FOUND')))).toBeInTheDocument();
  });

  it('saving the profile sends only what changed', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/patients/p1');
    const name = await screen.findByLabelText(msg('pat.field.fullName'));
    await user.clear(name);
    await user.type(name, 'Layla H. Hassan');
    await user.click(screen.getByRole('button', { name: msg('pat.profile.save') }));
    expect(await screen.findByText(msg('pat.profile.saved'))).toBeInTheDocument();
    const call = api.calls('PATCH', '/admin/patients/p1')[0]!;
    expect(call.body).toEqual({ fullName: 'Layla H. Hassan' });
    expect(call.headers['x-csrf-token']).toBe('csrf-admin');
  });

  it('deactivating needs a confirmation that explains the consequence; reactivating is direct', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/patients/p1');
    await user.click(await screen.findByRole('button', { name: msg('pat.deactivate') }));
    const dialog = await screen.findByRole('dialog', { name: msg('pat.deactivate.title') });
    expect(within(dialog).getByText(msg('pat.deactivate.text'))).toBeInTheDocument();
    expect(api.calls('PATCH', '/admin/patients/p1')).toHaveLength(0);
    await user.click(within(dialog).getByRole('button', { name: msg('pat.deactivate.confirm') }));
    expect(await screen.findByText(msg('pat.deactivated'))).toBeInTheDocument();
    expect(api.calls('PATCH', '/admin/patients/p1')[0]!.body).toEqual({ isActive: false });

    await user.click(await screen.findByRole('button', { name: msg('pat.reactivate') }));
    expect(await screen.findByText(msg('pat.reactivated'))).toBeInTheDocument();
    expect(api.calls('PATCH', '/admin/patients/p1')[1]!.body).toEqual({ isActive: true });
  });

  it('unlinking Telegram asks first, then calls the API', async () => {
    const { api } = setup({ patients: [patient({ telegramLinked: true })] });
    const user = userEvent.setup();
    renderAdmin('/patients/p1');
    await user.click(await screen.findByRole('button', { name: msg('pat.telegram.unlink') }));
    const dialog = await screen.findByRole('dialog', { name: msg('pat.telegram.unlink.title') });
    expect(api.calls('POST', /revoke$/)).toHaveLength(0);
    await user.click(within(dialog).getByRole('button', { name: msg('pat.telegram.unlink.confirm') }));
    expect(await screen.findByText(msg('pat.telegram.unlinked'))).toBeInTheDocument();
    expect(api.calls('POST', '/admin/patients/p1/telegram/revoke')[0]!.headers['x-csrf-token']).toBe('csrf-admin');
    await waitFor(() => expect(screen.getByText(msg('pat.telegram.notLinked'))).toBeInTheDocument());
  });
});

describe('staff-assisted password reset', () => {
  async function open(user: ReturnType<typeof userEvent.setup>) {
    await user.click(await screen.findByRole('button', { name: msg('pat.reset.button') }));
    return screen.findByRole('dialog', { name: msg('pat.reset.title') });
  }

  it('cannot be submitted without confirming the identity in person; then sends identityVerified and forgets the password', async () => {
    const { api } = setup();
    const user = userEvent.setup();
    renderAdmin('/patients/p1');
    const dialog = await open(user);
    expect(within(dialog).getByText(msg('pat.reset.intro'))).toBeInTheDocument();
    const field = within(dialog).getByLabelText(lbl(msg('pat.reset.new')));
    expect(field).toHaveAttribute('type', 'password');
    await user.type(field, 'fresh-password-9');
    const submit = within(dialog).getByRole('button', { name: msg('pat.reset.submit') });
    expect(submit).toBeDisabled();
    await user.click(within(dialog).getByRole('checkbox', { name: msg('pat.reset.identity') }));
    expect(submit).toBeEnabled();
    await user.click(submit);

    expect(await screen.findByText(msg('pat.reset.done'))).toBeInTheDocument();
    const call = api.calls('POST', '/admin/patients/p1/reset-password')[0]!;
    expect(call.body).toEqual({ newPassword: 'fresh-password-9', identityVerified: true });
    expect(call.headers['x-csrf-token']).toBe('csrf-admin');
    expect(document.body.innerHTML).not.toContain('fresh-password-9');
    await waitFor(() => expect(screen.queryByRole('dialog', { name: msg('pat.reset.title') })).not.toBeInTheDocument());
  });

  it('a weak password is explained inside the dialog; a double click sends one request', async () => {
    const { api } = setup();
    api.route(async (r) => { if (r.path.endsWith('/reset-password')) { await new Promise((res) => setTimeout(res, 40)); return fail(400, 'PASSWORD_TOO_WEAK'); } return undefined; });
    const user = userEvent.setup();
    renderAdmin('/patients/p1');
    const dialog = await open(user);
    await user.type(within(dialog).getByLabelText(lbl(msg('pat.reset.new'))), '12345678');
    await user.click(within(dialog).getByRole('checkbox'));
    await user.dblClick(within(dialog).getByRole('button', { name: msg('pat.reset.submit') }));
    expect(await within(dialog).findByText(msg('err.PASSWORD_TOO_WEAK'))).toBeInTheDocument();
    expect(api.calls('POST', /reset-password$/)).toHaveLength(1);
  });

  it('if the backend says the identity was not confirmed, that is shown', async () => {
    const { api } = setup();
    api.route((r) => (r.path.endsWith('/reset-password') ? fail(422, 'IDENTITY_CONFIRMATION_REQUIRED') : undefined));
    const user = userEvent.setup();
    renderAdmin('/patients/p1');
    const dialog = await open(user);
    await user.type(within(dialog).getByLabelText(lbl(msg('pat.reset.new'))), 'fresh-password-9');
    await user.click(within(dialog).getByRole('checkbox'));
    await user.click(within(dialog).getByRole('button', { name: msg('pat.reset.submit') }));
    expect(await within(dialog).findByText(msg('err.IDENTITY_CONFIRMATION_REQUIRED'))).toBeInTheDocument();
  });
});

describe('medical records', () => {
  it('lists records as plain text (markup is shown literally), with who wrote them, and offers no delete', async () => {
    setup({ records: [record({ notes: '<b>bold</b> <script>alert(1)</script>\nsecond line', diagnosis: '' })] });
    renderAdmin('/patients/p1');
    const item = await screen.findByTestId('medical-record');
    expect(within(item).getByText('Hypertension')).toBeInTheDocument();
    expect(within(item).getByText('Penicillin')).toBeInTheDocument();
    expect(within(item).queryByText(msg('mr.diagnosis'))).not.toBeInTheDocument(); // empty sections are not shown
    const notes = within(item).getByText(/second line/);
    expect(notes.textContent).toContain('<b>bold</b> <script>alert(1)</script>');
    expect(item.querySelector('b, script')).toBeNull();
    expect(within(item).getByText(msg('mr.created', 'en', { name: 'admin', when: '' }).trim(), { exact: false })).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: new RegExp(msg('common.delete'), 'i') })).not.toBeInTheDocument();
    expect(screen.getByText(msg('mr.notice'))).toBeInTheDocument();
  });

  it('creates a record, linked to one of the patient\'s appointments, and shows it', async () => {
    const { api } = setup({ records: [] });
    const user = userEvent.setup();
    renderAdmin('/patients/p1');
    expect(await screen.findByText(msg('mr.empty'))).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: msg('mr.add') }));
    const dialog = await screen.findByRole('dialog', { name: msg('mr.create.title') });
    await user.type(within(dialog).getByLabelText(lbl(msg('mr.allergies'))), 'Latex');
    await user.type(within(dialog).getByLabelText(lbl(msg('mr.treatment'))), 'Root canal, tooth 36');
    const select = within(dialog).getByLabelText(lbl(msg('mr.appointment')));
    await within(select).findByRole('option', { name: /Endodontics/ });
    await user.selectOptions(select, 'a1');
    await user.click(within(dialog).getByRole('button', { name: msg('mr.save') }));
    expect(await screen.findByText(msg('mr.saved'))).toBeInTheDocument();
    const call = api.calls('POST', '/admin/patients/p1/medical-records')[0]!;
    expect(call.body).toEqual({ medicalHistory: '', allergies: 'Latex', diagnosis: '', treatment: 'Root canal, tooth 36', notes: '', appointmentId: 'a1' });
    expect(call.headers['x-csrf-token']).toBe('csrf-admin');
    expect(await screen.findByText('Latex')).toBeInTheDocument();
  });

  it('an empty record cannot be saved, and a backend refusal is explained', async () => {
    const { api } = setup({ records: [] });
    api.route((r) => (r.method === 'POST' && r.path.endsWith('/medical-records') ? fail(400, 'EMPTY_RECORD') : undefined));
    const user = userEvent.setup();
    renderAdmin('/patients/p1');
    await user.click(await screen.findByRole('button', { name: msg('mr.add') }));
    const dialog = await screen.findByRole('dialog', { name: msg('mr.create.title') });
    expect(within(dialog).getByRole('button', { name: msg('mr.save') })).toBeDisabled();
    await user.type(within(dialog).getByLabelText(lbl(msg('mr.notes'))), 'x');
    await user.click(within(dialog).getByRole('button', { name: msg('mr.save') }));
    expect(await within(dialog).findByText(msg('err.EMPTY_RECORD'))).toBeInTheDocument();
  });

  it('edits an existing record with PATCH and never keeps the text after the dialog closes', async () => {
    const { api } = setup({ records: [record()] });
    const user = userEvent.setup();
    renderAdmin('/patients/p1');
    await user.click(await screen.findByRole('button', { name: msg('mr.edit') }));
    const dialog = await screen.findByRole('dialog', { name: msg('mr.edit.title') });
    const history = within(dialog).getByLabelText(lbl(msg('mr.history')));
    expect(history).toHaveValue('Hypertension');
    await user.clear(history);
    await user.type(history, 'Hypertension, diabetes');
    await user.click(within(dialog).getByRole('button', { name: msg('mr.save') }));
    expect(await screen.findByText(msg('mr.saved'))).toBeInTheDocument();
    const call = api.calls('PATCH', '/admin/medical-records/m1')[0]!;
    expect(call.body).toMatchObject({ medicalHistory: 'Hypertension, diabetes', allergies: 'Penicillin' });
    await waitFor(() => expect(screen.queryByRole('dialog', { name: msg('mr.edit.title') })).not.toBeInTheDocument());
    expect(JSON.stringify({ ...localStorage })).not.toContain('Hypertension');
    expect(JSON.stringify({ ...sessionStorage })).not.toContain('Hypertension');
  });

  it('a failure to load records is reported with a retry, not an empty list', async () => {
    const { api } = setup();
    let down = true;
    api.route((r) => (down && r.method === 'GET' && r.path.endsWith('/medical-records') ? fail(500, 'INTERNAL_ERROR') : undefined));
    const user = userEvent.setup();
    renderAdmin('/patients/p1');
    const retry = await screen.findByRole('button', { name: msg('common.retry') });
    expect(screen.queryByText(msg('mr.empty'))).not.toBeInTheDocument();
    down = false;
    await user.click(retry);
    expect(await screen.findByText(msg('mr.empty'))).toBeInTheDocument();
  });
});

describe('Arabic', () => {
  it('renders the patient page right-to-left with Arabic labels and a left-to-right phone number', async () => {
    setup();
    renderAdmin('/patients/p1', 'ar');
    expect(await screen.findByRole('heading', { level: 1, name: 'Layla Hassan' })).toBeInTheDocument();
    expect(document.documentElement.dir).toBe('rtl');
    expect(screen.getByRole('heading', { name: msg('mr.title', 'ar') })).toBeInTheDocument();
    expect(screen.getByLabelText(msg('pat.field.phone', 'ar'))).toHaveAttribute('dir', 'ltr');
  });
});
