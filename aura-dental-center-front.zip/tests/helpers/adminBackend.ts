import { vi } from 'vitest';
import { fail, json, ok, type Override, type Req } from './fakeBackend.js';
import type { AdminAppointment, DashboardData } from '../../src/admin/api/types.js';

export { fail, json, ok };
export type { Req, Override };

export const ADMIN = { id: 'adm-1', username: 'admin', fullName: 'Center Admin', mustChangePassword: false };

export function dashboardFixture(over: Partial<DashboardData> = {}): DashboardData {
  return {
    date: '2026-11-10', timezone: 'Africa/Cairo', counts: { booked: 2, completed: 1, no_show: 0, cancelled: 1 }, appointments: [],
    departments: [{ id: 'dep-1', slug: 'endodontics', name: 'Endodontics', activeToday: 2, capacity: 4 }],
    next7Days: [{ date: '2026-11-11', booked: 3 }], ...over,
  };
}

export function adminAppointmentFixture(over: Partial<AdminAppointment> = {}): AdminAppointment {
  return {
    id: 'a1', status: 'booked', department: { id: 'dep-1', slug: 'endodontics', name: 'Endodontics' }, dentist: { id: 'd1', name: 'Dr. Sample' }, service: null,
    date: '2026-11-10', slotNumber: 2, startsAt: '2026-11-10T18:00:00+02:00', endsAt: '2026-11-10T20:00:00+02:00', startTime: '18:00', endTime: '20:00', endsNextDay: false,
    patientNote: null, createdVia: 'web', rescheduledCount: 0, cancelledAt: null, cancelledBy: null,
    selfService: { canCancel: true, canReschedule: true, deadline: '2026-11-09T18:00:00+02:00', blockedReason: null },
    patient: { id: 'p1', fullName: 'Test Patient', phone: '+201000000009' }, cancelReason: null, ...over,
  };
}

/**
 * In-memory stand-in for the admin REST API. It answers the session endpoints and the dashboard itself; every other area
 * adds its own routes with `api.route(...)` (checked before the defaults) and reads what the UI sent from `api.log`.
 * Envelopes match the real backend exactly: { data }, { data, meta }, { error: { code, message } }, 204 without a body.
 */
export function startAdminBackend(opts: { signedIn?: boolean; mustChangePassword?: boolean; dashboard?: DashboardData } = {}) {
  const state = { signedIn: opts.signedIn ?? true, admin: { ...ADMIN, mustChangePassword: opts.mustChangePassword ?? false }, dashboard: opts.dashboard ?? dashboardFixture() };
  const log: Req[] = [];
  const overrides: Override[] = [];

  const route = (r: Req): Response => {
    if (r.method === 'POST' && r.path === '/admin/auth/login') {
      if (r.body.password !== 'correct-password-123') return fail(401, 'INVALID_CREDENTIALS');
      state.signedIn = true; return ok({ admin: state.admin, csrfToken: 'csrf-admin' });
    }
    if (r.method === 'GET' && r.path === '/admin/auth/me') return state.signedIn ? ok({ admin: state.admin, csrfToken: 'csrf-admin' }) : fail(401, 'UNAUTHENTICATED');
    if (r.method === 'POST' && r.path === '/admin/auth/logout') { state.signedIn = false; return new Response(null, { status: 204 }); }
    if (!state.signedIn) return fail(401, 'UNAUTHENTICATED');
    if (r.method === 'POST' && r.path === '/admin/auth/change-password') {
      if (r.body.currentPassword !== 'correct-password-123') return fail(401, 'INVALID_CREDENTIALS');
      if (String(r.body.newPassword).length < 12) return fail(400, 'PASSWORD_TOO_SHORT');
      state.admin = { ...state.admin, mustChangePassword: false }; return new Response(null, { status: 204 });
    }
    if (state.admin.mustChangePassword) return fail(403, 'PASSWORD_CHANGE_REQUIRED');
    if (r.method === 'GET' && r.path === '/admin/dashboard') return ok(state.dashboard);
    return fail(404, 'NOT_FOUND');
  };

  const fetchFn = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = new URL(String(input), 'http://localhost');
    const req: Req = {
      method: (init?.method ?? 'GET').toUpperCase(), path: url.pathname.replace(/^\/api\/v1/, ''), query: url.searchParams,
      body: typeof init?.body === 'string' ? JSON.parse(init.body) : undefined, headers: (init?.headers ?? {}) as Record<string, string>,
    };
    log.push(req);
    for (const o of overrides) { const r = await o(req); if (r) return r; }
    return route(req);
  });
  vi.stubGlobal('fetch', fetchFn);

  return {
    state, log,
    /** Handlers added here run before the defaults; return undefined to fall through to the next one. */
    route: (o: Override) => { overrides.unshift(o); },
    calls: (method: string, path: string | RegExp) => log.filter((r) => r.method === method && (typeof path === 'string' ? r.path === path : path.test(r.path))),
  };
}
