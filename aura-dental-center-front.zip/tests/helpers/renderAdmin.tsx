import { render } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { AdminProviders, LOCALE_STORAGE_KEY } from '../../src/admin/app/Providers.js';
import { AdminRoutes } from '../../src/admin/App.js';
import { http } from '../../src/admin/api/index.js';
import { adminMessages, type AdminKey } from '../../src/admin/i18n/messages.js';

/** Renders the whole dashboard (providers + routes) at `path`, in the given language (default English so text is readable in tests). */
export function renderAdmin(path = '/', locale: 'en' | 'ar' | 'fr' | null = 'en') {
  http.setCsrfToken(null);
  if (locale) localStorage.setItem(LOCALE_STORAGE_KEY, locale);
  return render(
    <MemoryRouter initialEntries={[path]}>
      <AdminProviders><AdminRoutes /></AdminProviders>
    </MemoryRouter>,
  );
}

/** Looks a message up in the bundle the dashboard actually uses, so tests check behaviour and survive wording changes. */
export function msg(key: AdminKey, locale: 'en' | 'ar' | 'fr' = 'en', vars: Record<string, string | number> = {}): string {
  const v = (adminMessages[locale] as Record<string, string>)[key];
  if (v === undefined) throw new Error(`test refers to a message key that does not exist: ${key}`);
  return v.replace(/\{(\w+)\}/g, (_m, k: string) => String(vars[k] ?? ''));
}
